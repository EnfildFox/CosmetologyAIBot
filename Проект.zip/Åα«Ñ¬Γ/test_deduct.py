#!/usr/bin/env python3
"""
Тестовый скрипт для проверки deduct_credits.
"""

from src.database import SyncSessionLocal as SessionLocal
from src.models import User, Tariff
from src.payment_utils import deduct_credits, check_access
from datetime import datetime

def test_deduct():
    session = SessionLocal()
    try:
        # Найти тестового пользователя
        user = session.query(User).filter(User.telegram_id == 123456789).first()  # Пример ID
        if not user:
            # Создать тестового пользователя
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            user = User(
                telegram_id=123456789,
                tariff_id=test_tariff.id if test_tariff else None,
                credits=50.0,
                used_text_today=0,
                last_reset_date=datetime.utcnow()
            )
            session.add(user)
            session.commit()

        print(f"Пользователь: {user.telegram_id}, credits: {user.credits}, used_text_today: {user.used_text_today}, tariff_id: {user.tariff_id}")

        # Проверить доступ
        access = check_access(user.telegram_id, 'text_diagnosis')
        print(f"Доступ к text_diagnosis: {access}")

        # Списать
        deduct_credits(user.telegram_id, 'text_diagnosis')

        # Проверить после
        session.refresh(user)
        print(f"После списания: credits: {user.credits}, used_text_today: {user.used_text_today}")

    finally:
        session.close()

if __name__ == "__main__":
    test_deduct()