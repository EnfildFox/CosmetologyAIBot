#!/usr/bin/env python3
"""
Скрипт для начисления 150 кредитов пользователю с telegram_id 5520597938.
Используется для тестирования логики бота.
"""

import sys
import os

# Добавляем корневую директорию проекта в путь
sys.path.insert(0, os.path.dirname(__file__))

from config.config import Config
from src.database import SyncSessionLocal as SessionLocal
from src.models import User

def add_credits_to_user(telegram_id: int, credits_to_add: float):
    """
    Начисляет указанное количество кредитов пользователю.

    :param telegram_id: Telegram ID пользователя
    :param credits_to_add: Количество кредитов для начисления
    """
    session = SessionLocal()
    try:
        # Находим пользователя по telegram_id
        user = session.query(User).filter(User.telegram_id == telegram_id).first()

        if not user:
            print(f"Пользователь с telegram_id {telegram_id} не найден.")
            return

        # Сохраняем старый баланс для вывода
        old_balance = user.credits

        # Добавляем кредиты
        user.credits += credits_to_add

        # Сохраняем изменения
        session.commit()

        # Выводим подтверждение
        print(f"Успешно начислено {credits_to_add} кредитов пользователю с telegram_id {telegram_id}.")
        print(f"Старый баланс: {old_balance}")
        print(f"Новый баланс: {user.credits}")

    except Exception as e:
        session.rollback()
        print(f"Ошибка при начислении кредитов: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    # Telegram ID пользователя
    TELEGRAM_ID = 5520597938
    # Количество кредитов для начисления
    CREDITS_TO_ADD = 100.0

    add_credits_to_user(TELEGRAM_ID, CREDITS_TO_ADD)