import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), '..', '.env'))

class Config:
    TELEGRAM_BOT_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
    OPENROUTER_API_KEY = os.getenv('OPENROUTER_API_KEY')
    DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///cosmetology_bot.db')
    YOOKASSA_SHOP_ID = os.getenv('YOOKASSA_SHOP_ID')
    YOOKASSA_SECRET_KEY = os.getenv('YOOKASSA_SECRET_KEY')
    ADMIN_IDS = [int(id.strip()) for id in os.getenv('ADMIN_IDS', '').split(',') if id.strip()]

    @classmethod
    def validate(cls):
        if not cls.TELEGRAM_BOT_TOKEN:
            raise ValueError("TELEGRAM_BOT_TOKEN не найден в .env файле")
        if not cls.OPENROUTER_API_KEY:
            raise ValueError("OPENROUTER_API_KEY не найден в .env файле")
        if not cls.YOOKASSA_SHOP_ID:
            raise ValueError("YOOKASSA_SHOP_ID не найден в .env файле")
        if not cls.YOOKASSA_SECRET_KEY:
            raise ValueError("YOOKASSA_SECRET_KEY не найден в .env файле")
        if not cls.ADMIN_IDS:
            raise ValueError("ADMIN_IDS не найден в .env файле")
