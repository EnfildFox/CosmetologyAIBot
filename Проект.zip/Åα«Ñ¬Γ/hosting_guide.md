# Руководство по хостингу Telegram бота на timeweb.cloud

## Введение

Это подробное руководство по развертыванию Telegram бота косметологии с функциями подписки, кредитов и платежей через Yookassa на платформе timeweb.cloud. Бот включает в себя основной бот (aiogram), веб-приложение для мини-приложения Telegram (Flask) и базу данных SQLite.

### Требования к хостингу
- VPS с Ubuntu 20.04+ или аналогичной ОС
- Минимум 1 ГБ RAM, 20 ГБ SSD
- Python 3.8+
- Доступ к SSH
- Доменное имя (опционально, но рекомендуется для HTTPS)

## Шаг 1: Регистрация и настройка сервера

### 1.1 Регистрация на timeweb.cloud
1. Перейдите на сайт [timeweb.cloud](https://timeweb.cloud)
2. Зарегистрируйтесь и выберите тариф VPS (рекомендуется "Start" или выше)
3. Выберите Ubuntu 22.04 LTS как ОС
4. Укажите SSH-ключ для безопасного доступа (сгенерируйте, если нет: `ssh-keygen -t rsa -b 4096`)

### 1.2 Первоначальная настройка сервера
После создания VPS подключитесь по SSH:

```bash
ssh root@your_server_ip
```

Обновите систему:
```bash
sudo apt update && sudo apt upgrade -y
```

Установите необходимые пакеты:
```bash
sudo apt install -y curl wget git ufw nginx python3 python3-pip python3-venv
```

### 1.3 Настройка firewall
```bash
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw --force enable
```

## Шаг 2: Установка Python и зависимостей

### 2.1 Установка Python 3.10 (если не установлен)
```bash
sudo apt install -y python3.10 python3.10-venv python3-pip
```

### 2.2 Создание виртуального окружения
```bash
mkdir ~/cosmetology_bot
cd ~/cosmetology_bot
python3 -m venv venv
source venv/bin/activate
```

### 2.3 Установка зависимостей
Скопируйте requirements.txt на сервер и установите:
```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 2.4 Установка системных зависимостей для OCR и изображений
```bash
sudo apt install -y tesseract-ocr tesseract-ocr-rus libtesseract-dev
```

## Шаг 3: Загрузка кода и конфигурация

### 3.1 Загрузка проекта
Используйте git для клонирования репозитория:
```bash
git clone https://github.com/your-repo/cosmetology_bot.git .
```

Или загрузите файлы через SCP/SFTP.

### 3.2 Настройка переменных окружения
Создайте файл .env:
```bash
nano .env
```

Содержимое:
```
TELEGRAM_BOT_TOKEN=your_telegram_bot_token_here
OPENROUTER_API_KEY=your_openrouter_api_key_here
YOOKASSA_SHOP_ID=your_yookassa_shop_id_here
YOOKASSA_SECRET_KEY=your_yookassa_secret_key_here
ADMIN_IDS=123456789,987654321
DATABASE_URL=sqlite:///cosmetology_bot.db
```

**Важно:** Замените значения на реальные ключи. Никогда не коммитите .env в git.

### 3.3 Настройка базы данных
Инициализируйте базу данных:
```bash
python -m src.main
# Прервите выполнение после создания таблиц (Ctrl+C)
```

## Шаг 4: Настройка systemd для автоматического запуска

### 4.1 Создание сервиса для бота
```bash
sudo nano /etc/systemd/system/cosmetology_bot.service
```

Содержимое:
```
[Unit]
Description=Cosmetology Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/cosmetology_bot
Environment=PATH=/home/ubuntu/cosmetology_bot/venv/bin
ExecStart=/home/ubuntu/cosmetology_bot/venv/bin/python -m src.main
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

**Примечание:** Замените `ubuntu` на вашего пользователя.

### 4.2 Создание сервиса для веб-приложения
```bash
sudo nano /etc/systemd/system/cosmetology_web.service
```

Содержимое:
```
[Unit]
Description=Cosmetology Web App
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/cosmetology_bot
Environment=PATH=/home/ubuntu/cosmetology_bot/venv/bin
ExecStart=/home/ubuntu/cosmetology_bot/venv/bin/python web/mini_app.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 4.3 Запуск сервисов
```bash
sudo systemctl daemon-reload
sudo systemctl enable cosmetology_bot
sudo systemctl enable cosmetology_web
sudo systemctl start cosmetology_bot
sudo systemctl start cosmetology_web
```

Проверка статуса:
```bash
sudo systemctl status cosmetology_bot
sudo systemctl status cosmetology_web
```

## Шаг 5: Настройка Nginx для веб-приложения

### 5.1 Установка и настройка Nginx
```bash
sudo apt install -y nginx
```

Создайте конфигурацию сайта:
```bash
sudo nano /etc/nginx/sites-available/cosmetology_app
```

Содержимое:
```
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Включите сайт:
```bash
sudo ln -s /etc/nginx/sites-available/cosmetology_app /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5.2 Настройка HTTPS (Let's Encrypt)
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your_domain.com
```

## Шаг 6: Меры безопасности

### 6.1 SSH hardening
Отключите root login и парольную аутентификацию:
```bash
sudo nano /etc/ssh/sshd_config
```

Измените:
```
PermitRootLogin no
PasswordAuthentication no
```

Перезапустите SSH:
```bash
sudo systemctl reload sshd
```

### 6.2 Защита от DDoS и ботов
Установите fail2ban:
```bash
sudo apt install -y fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 6.3 Регулярные обновления
Настройте автоматические обновления:
```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades
```

### 6.4 Мониторинг логов
Просмотр логов бота:
```bash
sudo journalctl -u cosmetology_bot -f
```

## Шаг 7: Тестирование и устранение неполадок

### 7.1 Тестирование бота
1. Проверьте, что бот отвечает на команды в Telegram
2. Протестируйте платежи через мини-приложение
3. Проверьте админ-панель

### 7.2 Тестирование веб-приложения
```bash
curl http://localhost:5000
```

Через браузер: `http://your_domain.com`

### 7.3 Возможные проблемы и решения

#### Проблема: Бот не запускается
- Проверьте логи: `sudo journalctl -u cosmetology_bot -n 50`
- Убедитесь, что все переменные окружения установлены
- Проверьте права доступа к файлам

#### Проблема: Веб-приложение не доступно
- Проверьте статус сервиса: `sudo systemctl status cosmetology_web`
- Проверьте Nginx: `sudo nginx -t`
- Проверьте firewall: `sudo ufw status`

#### Проблема: Платежи не обрабатываются
- Проверьте ключи Yookassa в .env
- Убедитесь, что веб-приложение имеет доступ к интернету
- Для production добавьте обработку вебхуков Yookassa

#### Проблема: Таймауты платежей
- Yookassa имеет лимиты на время ожидания платежа (обычно 30 минут)
- Добавьте обработку отмененных платежей
- Реализуйте вебхуки для мгновенного подтверждения

#### Проблема: Высокая нагрузка на CPU/память
- Мониторьте ресурсы: `htop`
- Оптимизируйте код (используйте async/await)
- Рассмотрите переход на PostgreSQL для большой нагрузки

### 7.4 Мониторинг производительности
Установите мониторинг:
```bash
sudo apt install -y htop iotop
```

Для продвинутого мониторинга рассмотрите Prometheus + Grafana.

## Шаг 8: Резервное копирование

### 8.1 Автоматическое бэкапирование базы данных
Создайте скрипт backup.sh:
```bash
#!/bin/bash
DATE=$(date +%Y%m%d_%H%M%S)
cp cosmetology_bot.db backup_$DATE.db
# Загрузите на облачное хранилище (Yandex Disk, Google Drive и т.д.)
```

Добавьте в cron:
```bash
crontab -e
# Добавьте: 0 2 * * * /home/ubuntu/cosmetology_bot/backup.sh
```

## Заключение

После выполнения всех шагов ваш бот должен быть полностью функциональным на timeweb.cloud. Регулярно проверяйте логи и обновляйте систему для поддержания безопасности.

Для вопросов или проблем обратитесь к документации timeweb.cloud или Telegram-сообществам разработчиков.