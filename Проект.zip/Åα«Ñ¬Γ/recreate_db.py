import os
from config import Config
from src.database import init_db

# Получаем путь к базе данных
db_url = Config.DATABASE_URL
if db_url.startswith('sqlite:///'):
    db_path = db_url[len('sqlite:///'):]
    if os.path.exists(db_path):
        os.remove(db_path)
        print(f"Удалена старая база данных: {db_path}")

# Пересоздаем базу данных с правильной схемой
init_db()
print("База данных пересоздана с правильной схемой.")