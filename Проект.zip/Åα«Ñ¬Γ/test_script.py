import unittest
from unittest.mock import Mock, patch, MagicMock, AsyncMock
import sys
import os
import asyncio

# Добавляем текущую директорию в путь для импорта модулей
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.payment_utils import check_access, deduct_credits, successful_payment
from src.ai_service import AIService
from src.handlers import handle_text_message, handle_photo_message, handle_document_message, successful_payment_handler
from aiogram import types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup


class TestCheckAccess(unittest.TestCase):
    """Тесты для функции check_access с mock данными."""

    @patch('payment_utils.SessionLocal')
    def test_check_access_with_subscription(self, mock_session_local):
        """Тест доступа с активной подпиской."""
        # Mock сессия
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        # Mock пользователь
        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 5

        # Mock сервис
        mock_service = Mock()
        mock_service.name = 'text_diagnosis'
        mock_service.price = 1

        # Mock подписка
        mock_subscription = Mock()
        mock_subscription.active = True
        mock_subscription.end_date = '2025-12-31'

        # Настройка query
        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, mock_service, mock_subscription]

        result = check_access(1, 'text_diagnosis')
        self.assertTrue(result)

    @patch('payment_utils.SessionLocal')
    def test_check_access_with_credits(self, mock_session_local):
        """Тест доступа с кредитами."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 5

        mock_service = Mock()
        mock_service.name = 'text_diagnosis'
        mock_service.price = 1

        # Нет подписки
        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, mock_service, None]

        result = check_access(1, 'text_diagnosis')
        self.assertTrue(result)

    @patch('payment_utils.SessionLocal')
    def test_check_access_insufficient_credits(self, mock_session_local):
        """Тест отказа доступа при недостатке кредитов."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 0

        mock_service = Mock()
        mock_service.name = 'text_diagnosis'
        mock_service.price = 1

        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, mock_service, None]

        result = check_access(1, 'text_diagnosis')
        self.assertFalse(result)

    @patch('payment_utils.SessionLocal')
    def test_check_access_user_not_found(self, mock_session_local):
        """Тест при отсутствии пользователя."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_session.query.return_value.filter.return_value.first.return_value = None

        result = check_access(1, 'text_diagnosis')
        self.assertFalse(result)


class TestAIService(unittest.IsolatedAsyncioTestCase):
    """Тесты для AIService с mock API."""

    @patch('google.generativeai')
    async def test_analyze_text_problem(self, mock_genai):
        """Тест анализа текста с mock API."""
        mock_model = Mock()
        mock_genai.configure = Mock()
        mock_genai.list_models = Mock(return_value=[])
        mock_genai.GenerativeModel.return_value = mock_model
        mock_response = Mock()
        mock_response.text = "Mock AI response"
        mock_model.generate_content = AsyncMock(return_value=mock_response)

        ai_service = AIService()
        result = await ai_service.analyze_text_problem("Test problem")
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
        self.assertIn("Mock AI response", result[0])

    @patch('google.generativeai')
    async def test_analyze_image(self, mock_genai):
        """Тест анализа изображения с mock API."""
        mock_model = Mock()
        mock_genai.configure = Mock()
        mock_genai.list_models = Mock(return_value=[])
        mock_genai.GenerativeModel.return_value = mock_model
        mock_response = Mock()
        mock_response.text = "Mock AI response"
        mock_model.generate_content = AsyncMock(return_value=mock_response)

        ai_service = AIService()
        mock_image_bytes = b"fake image data"
        with patch('ai_service.Image') as mock_image:
            mock_image.open.return_value = Mock()
            result = await ai_service.analyze_image(mock_image_bytes, "Test description")
            self.assertIsInstance(result, list)
            self.assertEqual(len(result), 1)
            self.assertIn("Mock AI response", result[0])

    @patch('google.generativeai')
    async def test_generate_content_post(self, mock_genai):
        """Тест генерации поста с mock API."""
        mock_model = Mock()
        mock_genai.configure = Mock()
        mock_genai.list_models = Mock(return_value=[])
        mock_genai.GenerativeModel.return_value = mock_model
        mock_response = Mock()
        mock_response.text = "Mock AI response"
        mock_model.generate_content = AsyncMock(return_value=mock_response)

        ai_service = AIService()
        result = await ai_service.generate_content_post("Test topic")
        self.assertIsInstance(result, dict)
        self.assertIn('text', result)
        self.assertIsInstance(result['text'], list)
        self.assertEqual(len(result['text']), 1)
        self.assertIn("Mock AI response", result['text'][0])


class TestDeductCredits(unittest.TestCase):
    """Тесты для функции deduct_credits."""

    @patch('payment_utils.SessionLocal')
    def test_deduct_credits_success(self, mock_session_local):
        """Тест успешного списания кредитов."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 10

        mock_service = Mock()
        mock_service.name = 'text_diagnosis'
        mock_service.price = 1

        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, mock_service]

        deduct_credits(1, 'text_diagnosis')

        self.assertEqual(mock_user.credits, 9)  # 10 - 1
        mock_session.add.assert_called()
        mock_session.commit.assert_called()

    @patch('payment_utils.SessionLocal')
    def test_deduct_credits_insufficient_credits(self, mock_session_local):
        """Тест списания при недостатке кредитов."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 0

        mock_service = Mock()
        mock_service.name = 'text_diagnosis'
        mock_service.price = 1

        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, mock_service]

        with self.assertRaises(ValueError) as context:
            deduct_credits(1, 'text_diagnosis')

        self.assertIn("Insufficient credits", str(context.exception))

    @patch('payment_utils.SessionLocal')
    def test_deduct_credits_user_not_found(self, mock_session_local):
        """Тест списания при отсутствии пользователя."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_session.query.return_value.filter.return_value.first.return_value = None

        with self.assertRaises(ValueError) as context:
            deduct_credits(1, 'text_diagnosis')

        self.assertIn("User not found", str(context.exception))

    @patch('payment_utils.SessionLocal')
    def test_deduct_credits_service_not_found(self, mock_session_local):
        """Тест списания при отсутствии сервиса."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 10

        mock_session.query.return_value.filter.return_value.first.side_effect = [mock_user, None]

        with self.assertRaises(ValueError) as context:
            deduct_credits(1, 'text_diagnosis')

        self.assertIn("Service not found", str(context.exception))


class TestSuccessfulPayment(unittest.TestCase):
    """Тесты для функции successful_payment."""

    @patch('payment_utils.SessionLocal')
    def test_successful_payment_success(self, mock_session_local):
        """Тест успешного добавления кредитов."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_user = Mock()
        mock_user.id = 1
        mock_user.credits = 5

        mock_session.query.return_value.filter.return_value.first.return_value = mock_user

        successful_payment(1, 10, "purchase", "Test purchase")

        self.assertEqual(mock_user.credits, 15)  # 5 + 10
        mock_session.add.assert_called()
        mock_session.commit.assert_called()

    @patch('payment_utils.SessionLocal')
    def test_successful_payment_user_not_found(self, mock_session_local):
        """Тест добавления кредитов при отсутствии пользователя."""
        mock_session = Mock()
        mock_session_local.return_value = mock_session

        mock_session.query.return_value.filter.return_value.first.return_value = None

        with self.assertRaises(ValueError) as context:
            successful_payment(1, 10, "purchase", "Test purchase")

        self.assertIn("User not found", str(context.exception))


class TestPaymentHandlers(unittest.IsolatedAsyncioTestCase):
    """Тесты для обработчиков платежей."""

    def setUp(self):
        """Настройка mock объектов."""
        self.mock_message = Mock()
        self.mock_message.from_user = Mock()
        self.mock_message.from_user.id = 1
        self.mock_message.successful_payment = Mock()
        self.mock_message.successful_payment.invoice_payload = "credits_10_1"
        self.mock_message.answer = AsyncMock()

    @patch('handlers.successful_payment')
    async def test_successful_payment_handler_credits(self, mock_successful_payment):
        """Тест обработчика успешного платежа за кредиты."""
        await successful_payment_handler(self.mock_message)

        mock_successful_payment.assert_called_with(1, 10, "purchase", "Покупка 10 кредитов")
        self.mock_message.answer.assert_called()

    @patch('handlers.successful_payment')
    async def test_successful_payment_handler_subscription(self, mock_successful_payment):
        """Тест обработчика успешного платежа за подписку."""
        self.mock_message.successful_payment.invoice_payload = "subscription_1_1"

        mock_session = Mock()
        with patch('handlers.SessionLocal', return_value=mock_session):
            mock_service = Mock()
            mock_service.id = 1
            mock_service.name = "Test Service"
            mock_service.price = 100

            mock_user = Mock()
            mock_user.id = 1

            mock_session.query.return_value.filter.return_value.first.side_effect = [mock_service, mock_user]

            await successful_payment_handler(self.mock_message)

            # Проверяем, что подписка и транзакция добавлены
            self.assertEqual(mock_session.add.call_count, 2)  # Subscription and Transaction
            mock_session.commit.assert_called()
            self.mock_message.answer.assert_called()

    async def test_successful_payment_handler_invalid_payload(self):
        """Тест обработчика с неверным payload."""
        self.mock_message.successful_payment.invoice_payload = "invalid_payload"

        await successful_payment_handler(self.mock_message)

        # Должен ответить об ошибке
        self.mock_message.answer.assert_called()


class TestHandlers(unittest.IsolatedAsyncioTestCase):
    """Тесты для handlers с mock message."""

    def setUp(self):
        """Настройка mock объектов."""
        self.mock_message = Mock()
        self.mock_message.from_user = Mock()
        self.mock_message.from_user.id = 1
        self.mock_message.text = "Test message"
        self.mock_message.photo = [Mock()]
        self.mock_message.photo[-1].file_id = "test_file_id"
        self.mock_message.document = Mock()
        self.mock_message.document.file_id = "test_doc_id"
        self.mock_message.document.file_name = "test.pdf"
        self.mock_message.document.mime_type = "application/pdf"
        self.mock_message.answer = AsyncMock()
        self.mock_message.bot = Mock()
        self.mock_message.bot.get_file = AsyncMock(return_value=Mock(file_path="test_path"))
        self.mock_message.bot.download_file = AsyncMock(return_value=Mock(read=Mock(return_value=b"fake data")))

        self.mock_state = Mock(spec=FSMContext)
        self.mock_state.get_state.return_value = "UserState:waiting_for_diagnostics"

    @patch('handlers.ai_service')
    @patch('handlers.check_access')
    @patch('handlers.SessionLocal')
    async def test_handle_text_message_diagnostics(self, mock_session_local, mock_check_access, mock_ai_service):
        """Тест обработки текстового сообщения для диагностики."""
        mock_check_access.return_value = True
        mock_ai_service.analyze_text_problem = AsyncMock(return_value=["Mock response"])

        # Mock сессия для пользователя
        mock_session = Mock()
        mock_session_local.return_value = mock_session
        mock_user = Mock()
        mock_user.credits = 10
        mock_session.query.return_value.filter.return_value.first.return_value = mock_user

        await handle_text_message(self.mock_message, self.mock_state)

        mock_check_access.assert_called_with(1, 'text_diagnosis')
        mock_ai_service.analyze_text_problem.assert_called_with("Test message")

    @patch('handlers.ai_service')
    @patch('handlers.check_access')
    async def test_handle_photo_message(self, mock_check_access, mock_ai_service):
        """Тест обработки фото сообщения."""
        mock_check_access.return_value = True
        mock_ai_service.analyze_image = AsyncMock(return_value=["Mock image response"])

        self.mock_state.get_state.return_value = "UserState:waiting_for_photo"

        await handle_photo_message(self.mock_message, self.mock_state)

        mock_check_access.assert_called_with(1, 'photo_analysis')
        mock_ai_service.analyze_image.assert_called()

    @patch('handlers.ai_service')
    @patch('handlers.check_access')
    async def test_handle_document_message_pdf(self, mock_check_access, mock_ai_service):
        """Тест обработки PDF документа."""
        mock_check_access.return_value = True
        mock_ai_service.extract_text_from_pdf.return_value = "Extracted text"
        mock_ai_service.analyze_document_text = AsyncMock(return_value=["Mock document response"])

        self.mock_state.get_state.return_value = "UserState:waiting_for_document"

        await handle_document_message(self.mock_message, self.mock_state)

        mock_check_access.assert_called_with(1, 'document_analysis')
        mock_ai_service.extract_text_from_pdf.assert_called()
        mock_ai_service.analyze_document_text.assert_called_with("Extracted text")


if __name__ == '__main__':
    unittest.main()