#!/usr/bin/env python3
"""
Скрипт для проверки и исправления существующих транзакций в базе данных.

Задачи:
1. Найти все транзакции пользователя 5520597938
2. Проверить, какой user.id у них указан
3. Исправить user.id на правильный (из таблицы User)
4. Проверить работу истории после исправления
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.database import SyncSessionLocal as SessionLocal
from src.models import User, Transaction

def main():
    session = SessionLocal()
    try:
        # Шаг 1: Найти пользователя с telegram_id 5520597938
        target_telegram_id = 5520597938
        user = session.query(User).filter(User.telegram_id == target_telegram_id).first()

        if not user:
            print(f"Пользователь с telegram_id {target_telegram_id} не найден")
            return

        print(f"Найден пользователь: id={user.id}, telegram_id={user.telegram_id}")

        # Шаг 2: Найти все транзакции, связанные с этим пользователем
        # Ищем транзакции где user_id == user.id (правильные) или user_id == user.telegram_id (неправильные)
        transactions = session.query(Transaction).filter(
            (Transaction.user_id == user.id) | (Transaction.user_id == user.telegram_id)
        ).order_by(Transaction.created_at.desc()).all()

        print(f"\nНайдено {len(transactions)} транзакций для пользователя {target_telegram_id}:")

        incorrect_transactions = []
        for trans in transactions:
            print(f"ID: {trans.id}, user_id: {trans.user_id}, type: {trans.type}, amount: {trans.amount}, description: {trans.description}")
            if trans.user_id != user.id:
                incorrect_transactions.append(trans)

        # Шаг 3: Исправить неправильные транзакции
        if incorrect_transactions:
            print(f"\nНайдено {len(incorrect_transactions)} транзакций с неправильным user_id. Исправляем...")
            for trans in incorrect_transactions:
                print(f"Исправляю транзакцию ID {trans.id}: user_id {trans.user_id} -> {user.id}")
                trans.user_id = user.id
            session.commit()
            print("Исправления сохранены в базе данных.")
        else:
            print("\nВсе транзакции имеют правильный user_id.")

        # Шаг 4: Проверить работу истории после исправления
        print("\nПроверяем историю транзакций после исправления:")
        updated_transactions = session.query(Transaction).filter(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(10).all()

        print(f"История транзакций пользователя {target_telegram_id} (последние 10):")
        for trans in updated_transactions:
            print(f"• {trans.created_at.strftime('%d.%m.%Y %H:%M')} - {trans.type}: {trans.amount:.2f} ({trans.description})")

    except Exception as e:
        print(f"Ошибка: {e}")
        session.rollback()
    finally:
        session.close()

if __name__ == "__main__":
    main()