#!/bin/bash

# Скрипт для автоматического обновления кода на сервере timeweb.cloud
# Заполните переменные ниже перед запуском

# SSH параметры
SSH_USER="your_ssh_user"  # Например, root или ваш пользователь
SSH_HOST="your_server_ip_or_domain"  # IP адрес или домен сервера
SSH_KEY_PATH="~/.ssh/your_private_key"  # Путь к приватному ключу SSH (если используется ключ)

# Директория проекта на сервере
PROJECT_DIR="/path/to/your/project"  # Полный путь к директории проекта на сервере

# Имя виртуального окружения
VENV_DIR="venv"  # Имя директории виртуального окружения

# Сервис для перезапуска (если используется systemd)
SERVICE_NAME="your_service_name"  # Имя сервиса, например, cosmetology_bot или web_app

# Функция для выполнения команд на сервере
execute_on_server() {
    ssh -i "$SSH_KEY_PATH" "$SSH_USER@$SSH_HOST" "$1"
}

echo "Подключение к серверу и обновление кода..."

# Переход в директорию проекта
execute_on_server "cd $PROJECT_DIR"

# Активация виртуального окружения
execute_on_server "cd $PROJECT_DIR && source $VENV_DIR/bin/activate"

# Git pull
echo "Выполнение git pull..."
execute_on_server "cd $PROJECT_DIR && source $VENV_DIR/bin/activate && git pull"

# Обновление зависимостей
echo "Обновление зависимостей..."
execute_on_server "cd $PROJECT_DIR && source $VENV_DIR/bin/activate && pip install -r requirements.txt"

# Перезапуск сервисов
echo "Перезапуск сервиса $SERVICE_NAME..."
execute_on_server "sudo systemctl restart $SERVICE_NAME"

# Проверка статуса
echo "Проверка статуса сервиса..."
STATUS=$(execute_on_server "sudo systemctl status $SERVICE_NAME --no-pager -l")
echo "$STATUS"

echo "Обновление завершено."