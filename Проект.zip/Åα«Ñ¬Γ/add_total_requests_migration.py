#!/usr/bin/env python3
"""
Скрипт миграции базы данных для добавления поля total_requests в таблицу users.
"""

import sqlite3
from config.config import Config

def migrate_users_table():
    """Миграция таблицы users: добавление колонки total_requests."""
    db_path = Config.DATABASE_URL.replace('sqlite:///', '')

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Проверить, существует ли колонка total_requests
        cursor.execute("PRAGMA table_info(users)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]

        if 'total_requests' not in column_names:
            print("Начинаем миграцию: добавление колонки 'total_requests' в таблицу users")

            # Добавить колонку
            cursor.execute("ALTER TABLE users ADD COLUMN total_requests INTEGER DEFAULT 0")

            conn.commit()
            print("Миграция завершена успешно: колонка total_requests добавлена")
        else:
            print("Миграция не требуется: колонка 'total_requests' уже существует")

    except Exception as e:
        print(f"Ошибка при миграции: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_users_table()