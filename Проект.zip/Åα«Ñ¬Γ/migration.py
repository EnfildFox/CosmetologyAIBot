#!/usr/bin/env python3
"""
Скрипт миграции базы данных для исправления схемы packages.
Переименовывает колонку 'quotas' на 'credits' в таблице packages.
"""

import sqlite3
from config.config import Config

def migrate_packages_table():
    """Миграция таблицы packages: переименование колонки quotas на credits."""
    db_path = Config.DATABASE_URL.replace('sqlite:///', '')

    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    try:
        # Проверить, существует ли колонка quotas
        cursor.execute("PRAGMA table_info(packages)")
        columns = cursor.fetchall()
        column_names = [col[1] for col in columns]

        if 'quotas' in column_names and 'credits' not in column_names:
            print("Начинаем миграцию: переименование колонки 'quotas' на 'credits' в таблице packages")

            # Создать новую таблицу с правильной схемой
            cursor.execute('''
                CREATE TABLE packages_new (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    credits REAL NOT NULL,
                    price REAL NOT NULL
                )
            ''')

            # Скопировать данные (предполагаем, что quotas был числом, но в коде он dict, что странно)
            # В старом коде quotas был dict, но модель credits float, так что нужно адаптировать
            # Поскольку в init_db quotas был dict, но теперь credits float, возможно, данные нужно пересчитать
            # Для простоты, если quotas был dict, суммируем значения или что-то подобное
            # Но в примере {'photo': 30, 'text': 10} -> 40, {'analysis': 80, 'post': 50} -> 130
            # Но лучше оставить как есть и исправить данные вручную или пересчитать

            # Для миграции, поскольку старая колонка quotas была JSON, а новая credits float,
            # нужно решить, как конвертировать. Возможно, суммировать значения dict или взять фиксированные значения.

            # В данном случае, поскольку init_db изменен, и старая БД может иметь старые данные,
            # давайте предположим, что для существующих записей credits = сумма значений quotas

            cursor.execute("SELECT id, name, quotas, price FROM packages")
            rows = cursor.fetchall()

            for row in rows:
                package_id, name, quotas_str, price = row
                # quotas был JSON, распарсим
                import json
                try:
                    quotas = json.loads(quotas_str)
                    # Суммируем значения, предполагая, что они числа
                    credits_value = sum(v for v in quotas.values() if isinstance(v, (int, float)))
                except:
                    # Если не JSON или ошибка, поставить 0 или фиксированное значение
                    credits_value = 0

                cursor.execute("INSERT INTO packages_new (id, name, credits, price) VALUES (?, ?, ?, ?)",
                             (package_id, name, credits_value, price))

            # Удалить старую таблицу
            cursor.execute("DROP TABLE packages")

            # Переименовать новую таблицу
            cursor.execute("ALTER TABLE packages_new RENAME TO packages")

            conn.commit()
            print("Миграция завершена успешно")
        else:
            print("Миграция не требуется: колонка 'credits' уже существует или 'quotas' отсутствует")

    except Exception as e:
        print(f"Ошибка при миграции: {e}")
        conn.rollback()
    finally:
        conn.close()

if __name__ == "__main__":
    migrate_packages_table()