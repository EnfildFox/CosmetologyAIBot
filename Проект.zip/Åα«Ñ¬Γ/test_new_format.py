import asyncio
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.ai_service import AIService

async def test_new_format():
    ai_service = AIService()
    if not ai_service.client:
        print("AI клиент не инициализирован. Проверьте OPENROUTER_API_KEY.")
        return

    # Тестовый запрос
    test_problem = "У пациента красные пятна на коже лица, зудит."
    user_id = 1  # Тестовый user_id

    try:
        responses = await ai_service.analyze_text_problem(user_id, test_problem)
        print("Ответ AI:")
        for part in responses:
            print(part)
            print("---")

        # Проверка на наличие эмодзи и Markdown
        full_response = " ".join(responses)
        has_emoji = any(char in full_response for char in ['🔍', '💡', '⚠️', '**', '*', '`', '#', '- ', '1. '])
        if has_emoji:
            print("✅ Новый формат поддерживается: найдены эмодзи и/или Markdown элементы.")
        else:
            print("❌ Новый формат не применяется: нет эмодзи или Markdown.")

    except Exception as e:
        print(f"Ошибка при тестировании: {e}")

if __name__ == "__main__":
    asyncio.run(test_new_format())