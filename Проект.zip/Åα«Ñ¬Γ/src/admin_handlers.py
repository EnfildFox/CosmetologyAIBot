"""
Admin handlers module for Cosmetology AI Bot.

Этот модуль содержит обработчики для админ панели,
включая просмотр логов, управление пользователями и другие функции.
"""

from aiogram import Router, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from .utils import is_admin_check, markdown_to_html
from config.config import Config as config
from .database import SyncSessionLocal as SessionLocal
from .models import Setting, Subscription, Transaction, User
from sqlalchemy.orm import selectinload
import logging
import os
import asyncio
from datetime import datetime, timedelta

logger = logging.getLogger('cosmetology_bot')

admin_router = Router()

# Постоянная клавиатура для всех ответов бота
persistent_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="👤 Профиль"), KeyboardButton(text="❓ Помощь")],
        [KeyboardButton(text="💬 Меню"), KeyboardButton(text="🔙 Назад в чат")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Глобальный словарь для хранения ожидающих рассылок
pending_broadcasts = {}

# Глобальный словарь для хранения ожидающих вводов настроек
pending_settings_input = {}


# ═══════════════════════════════════════════════════════════════
# 📋 ПРОСМОТР ЛОГОВ
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_logs")
async def admin_logs_callback(c: types.CallbackQuery):
    """Обработчик callback Просмотр логов."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    # Показать последние логи, страница 1
    await show_logs_page(c.message, 1)
    await c.answer()


async def show_logs_page(message: types.Message, page: int):
    """Показать страницу логов."""
    log_file = "bot.log"
    lines_per_page = 10
    total_lines_to_read = 100  # Читать последние 100 строк

    try:
        if not os.path.exists(log_file):
            await message.answer(markdown_to_html("📋 Файл логов не найден."), parse_mode="HTML")
            return

        # Читаем последние строки
        with open(log_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        recent_lines = lines[-total_lines_to_read:] if len(lines) > total_lines_to_read else lines
        total_pages = (len(recent_lines) + lines_per_page - 1) // lines_per_page

        if page < 1 or page > total_pages:
            page = 1

        start_idx = (page - 1) * lines_per_page
        end_idx = start_idx + lines_per_page
        page_lines = recent_lines[start_idx:end_idx]

        # Форматируем логи
        log_text = f"📋 *Логи бота (страница {page}/{total_pages})*\n\n"
        for i, line in enumerate(page_lines, start=start_idx + 1):
            # Обрезаем длинные строки
            line = line.strip()
            if len(line) > 100:
                line = line[:97] + "..."
            log_text += f"{i}. {line}\n"

        if not page_lines:
            log_text += "Логи пусты."

        # Клавиатура навигации
        keyboard = []
        if page > 1:
            keyboard.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"logs_page_{page-1}"))
        if page < total_pages:
            keyboard.append(InlineKeyboardButton(text="➡️ Далее", callback_data=f"logs_page_{page+1}"))
        keyboard.append(InlineKeyboardButton(text="🔙 Назад в профиль", callback_data="back_to_profile"))

        reply_markup = InlineKeyboardMarkup(inline_keyboard=[keyboard]) if keyboard else None

        await message.answer(markdown_to_html(log_text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при чтении логов: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при чтении логов."), parse_mode="HTML")


@admin_router.callback_query(lambda c: c.data.startswith("logs_page_"))
async def logs_page_callback(c: types.CallbackQuery):
    """Обработчик навигации по страницам логов."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        page = int(c.data.split("_")[2])
        await show_logs_page(c.message, page)
    except ValueError:
        await c.answer("Неверная страница")
    await c.answer()


@admin_router.callback_query(lambda c: c.data == "back_to_profile")
async def back_to_profile_callback(c: types.CallbackQuery):
    """Обработчик возврата в профиль."""
    # Импортируем здесь чтобы избежать циклического импорта
    from .handlers import profile_command
    await profile_command(c.message)
    await c.answer()


# ═══════════════════════════════════════════════════════════════
# ⚙️ НАСТРОЙКИ ПАРАМЕТРОВ
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_settings")
async def admin_settings_callback(c: types.CallbackQuery):
    """Обработчик callback Настройки параметров."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    await show_settings_menu(c.message)
    await c.answer()


async def show_settings_menu(message: types.Message):
    """Показать меню настроек."""
    session = SessionLocal()
    try:
        settings = session.query(Setting).all()

        text = "⚙️ *Настройки параметров бота*\n\n"
        keyboard = []

        for setting in settings:
            text += f"**{setting.key}**: {setting.value}\n*{setting.description}*\n\n"
            keyboard.append([
                InlineKeyboardButton(text=f"Изменить {setting.key}", callback_data=f"edit_setting_{setting.id}")
            ])

        keyboard.append([InlineKeyboardButton(text="➕ Добавить настройку", callback_data="add_setting")])
        keyboard.append([InlineKeyboardButton(text="🔙 Назад в профиль", callback_data="back_to_profile")])

        reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
        await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при получении настроек: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при загрузке настроек."), parse_mode="HTML")
    finally:
        session.close()


@admin_router.callback_query(lambda c: c.data.startswith("edit_setting_"))
async def edit_setting_callback(c: types.CallbackQuery):
    """Обработчик редактирования настройки."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        setting_id = int(c.data.split("_")[2])
        session = SessionLocal()
        setting = session.query(Setting).filter(Setting.id == setting_id).first()
        session.close()

        if not setting:
            await c.message.answer(markdown_to_html("⚠️ Настройка не найдена."), parse_mode="HTML")
            return

        await show_setting_editor(c.message, setting)
    except ValueError:
        await c.answer("Неверный ID настройки")
    await c.answer()


async def show_setting_editor(message: types.Message, setting: Setting):
    """Показать редактор настройки."""
    text = f"⚙️ *Редактирование настройки*\n\n**{setting.key}**\n*{setting.description}*\n\nТекущее значение: `{setting.value}`"

    keyboard = [
        [InlineKeyboardButton(text="✏️ Ввести новое значение", callback_data=f"input_value_{setting.id}")],
        [InlineKeyboardButton(text="🔙 Назад к настройкам", callback_data="admin_settings")]
    ]

    reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
    await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)


@admin_router.callback_query(lambda c: c.data.startswith("input_value_"))
async def input_value_callback(c: types.CallbackQuery):
    """Обработчик ввода нового значения."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        setting_id = int(c.data.split("_")[2])
        await c.message.answer(markdown_to_html("📝 Введите новое значение для настройки:"), parse_mode="HTML")
        # Устанавливаем состояние для ожидания ввода
        # В aiogram для этого используется FSM, но для простоты используем callback с ожиданием
        # Фактически, для ввода текста лучше использовать message handler, но поскольку это callback, предложим ввести в следующем сообщении
        # Для упрощения, используем reply_markup с кнопками для типичных значений или inline input
        await show_value_input_keyboard(c.message, setting_id)
    except ValueError:
        await c.answer("Неверный ID настройки")
    await c.answer()


async def show_value_input_keyboard(message: types.Message, setting_id: int):
    """Показать клавиатуру для ввода значения."""
    session = SessionLocal()
    try:
        setting = session.query(Setting).filter(Setting.id == setting_id).first()
        if not setting:
            await message.answer(markdown_to_html("⚠️ Настройка не найдена."), parse_mode="HTML")
            return

        text = f"📝 Введите новое значение для **{setting.key}** или выберите из предложенных:"

        # Предлагаем типичные значения в зависимости от ключа
        keyboard = []
        if "limit" in setting.key.lower() or "max" in setting.key.lower():
            # Для лимитов предлагаем числа
            values = ["10", "50", "100", "500", "1000", "5000"]
            keyboard = [[InlineKeyboardButton(text=str(v), callback_data=f"set_value_{setting_id}_{v}")] for v in values]
        elif "enabled" in setting.key.lower() or "active" in setting.key.lower():
            # Для булевых значений
            keyboard = [
                [InlineKeyboardButton(text="Включено", callback_data=f"set_value_{setting_id}_true")],
                [InlineKeyboardButton(text="Отключено", callback_data=f"set_value_{setting_id}_false")]
            ]
        else:
            # Для других значений предлагаем ввод вручную
            keyboard = [[InlineKeyboardButton(text="✏️ Ввести вручную", callback_data=f"manual_input_{setting_id}")]]
            keyboard.append([InlineKeyboardButton(text="Отмена", callback_data="admin_settings")])

        reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
        await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при показе клавиатуры ввода: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка."), parse_mode="HTML")
    finally:
        session.close()


@admin_router.callback_query(lambda c: c.data.startswith("set_value_"))
async def set_value_callback(c: types.CallbackQuery):
    """Обработчик установки значения."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        parts = c.data.split("_")
        setting_id = int(parts[2])
        value = "_".join(parts[3:])  # В случае если значение содержит _

        session = SessionLocal()
        setting = session.query(Setting).filter(Setting.id == setting_id).first()
        if setting:
            setting.value = value
            session.commit()
            await c.message.answer(markdown_to_html(f"✅ Значение настройки **{setting.key}** обновлено на: `{value}`"), parse_mode="HTML")
        else:
            await c.message.answer(markdown_to_html("⚠️ Настройка не найдена."), parse_mode="HTML")
        session.close()

        await show_settings_menu(c.message)
    except Exception as e:
        logger.error(f"Ошибка при установке значения: {e}")
        await c.message.answer(markdown_to_html("⚠️ Ошибка при сохранении."), parse_mode="HTML")
    await c.answer()


@admin_router.callback_query(lambda c: c.data.startswith("manual_input_"))
async def manual_input_callback(c: types.CallbackQuery):
    """Обработчик ручного ввода."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        setting_id = int(c.data.split("_")[2])
        pending_settings_input[c.from_user.id] = setting_id
        await c.message.answer(markdown_to_html("📝 Отправьте сообщение с новым значением:"), parse_mode="HTML")
    except ValueError:
        await c.answer("Неверный ID настройки")
    await c.answer()


@admin_router.callback_query(lambda c: c.data == "add_setting")
async def add_setting_callback(c: types.CallbackQuery):
    """Обработчик добавления новой настройки."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    await c.message.answer(markdown_to_html("➕ Функция добавления настроек будет реализована позже."), parse_mode="HTML")
    await c.answer()


# ═══════════════════════════════════════════════════════════════
# 💳 МОНИТОРИНГ ПЛАТЕЖЕЙ И ТРАНЗАКЦИЙ
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_payments")
async def admin_payments_callback(c: types.CallbackQuery):
    """Обработчик callback Мониторинг платежей."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    await show_payments_menu(c.message)
    await c.answer()


async def show_payments_menu(message: types.Message):
    """Показать меню мониторинга платежей."""
    text = "💳 *Мониторинг платежей и транзакций*\n\nВыберите действие:"

    keyboard = [
        [InlineKeyboardButton(text="📊 Статистика платежей", callback_data="admin_payment_stats")],
        [InlineKeyboardButton(text="📋 Просмотр транзакций", callback_data="admin_transactions")],
        [InlineKeyboardButton(text="🔙 Назад в профиль", callback_data="back_to_profile")]
    ]

    reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
    await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)


@admin_router.callback_query(lambda c: c.data == "admin_payment_stats")
async def admin_payment_stats_callback(c: types.CallbackQuery):
    """Обработчик callback Статистика платежей."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    session = SessionLocal()
    try:
        # Общая статистика
        total_transactions = session.query(Transaction).count()
        payment_transactions = session.query(Transaction).filter(Transaction.amount > 0).all()
        total_revenue = sum(t.amount for t in payment_transactions)
        credit_usage_transactions = session.query(Transaction).filter(Transaction.type == "credit_usage").all()
        total_credits_spent = sum(abs(t.amount) for t in credit_usage_transactions)

        # Статистика по типам платежей
        package_payments = session.query(Transaction).filter(Transaction.type == "package_purchase").count()
        tariff_payments = session.query(Transaction).filter(Transaction.type == "tariff").count()

        # Статистика за последний месяц
        one_month_ago = datetime.now() - timedelta(days=30)
        recent_payments = session.query(Transaction).filter(
            Transaction.created_at >= one_month_ago,
            Transaction.amount > 0
        ).all()
        recent_revenue = sum(t.amount for t in recent_payments)

        stats_text = f"""
💳 *Статистика платежей*

📊 *Общая статистика:*
• Всего транзакций: {total_transactions}
• Общий доход: {total_revenue:.2f} ₽
• Потрачено кредитов: {total_credits_spent:.2f}

💰 *По типам платежей:*
• Покупки пакетов: {package_payments}
• Оформление тарифов: {tariff_payments}

📅 *За последний месяц:*
• Доход: {recent_revenue:.2f} ₽
• Количество платежей: {len(recent_payments)}
"""

        keyboard = [
            [InlineKeyboardButton(text="🔄 Обновить", callback_data="admin_payment_stats")],
            [InlineKeyboardButton(text="🔙 Назад к платежам", callback_data="admin_payments")]
        ]

        reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
        await c.message.answer(markdown_to_html(stats_text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при получении статистики платежей: {e}")
        await c.message.answer(markdown_to_html("⚠️ Ошибка при загрузке статистики."), parse_mode="HTML")
    finally:
        session.close()
    await c.answer()


@admin_router.callback_query(lambda c: c.data == "admin_transactions")
async def admin_transactions_callback(c: types.CallbackQuery):
    """Обработчик callback Просмотр транзакций."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    # Показать последние транзакции, страница 1
    await show_transactions_page(c.message, 1)
    await c.answer()


async def show_transactions_page(message: types.Message, page: int):
    """Показать страницу транзакций."""
    session = SessionLocal()
    try:
        transactions_per_page = 10
        offset = (page - 1) * transactions_per_page

        # Получить транзакции с пользователями
        transactions = session.query(Transaction).join(User).order_by(Transaction.created_at.desc()).offset(offset).limit(transactions_per_page).all()
        total_transactions = session.query(Transaction).count()
        total_pages = (total_transactions + transactions_per_page - 1) // transactions_per_page

        if page < 1 or page > total_pages:
            page = 1

        # Форматировать транзакции
        trans_text = f"📋 *Транзакции (страница {page}/{total_pages})*\n\n"
        for trans in transactions:
            user = session.query(User).filter(User.id == trans.user_id).first()
            username = f"@{user.telegram_id}" if user else "Неизвестный"
            amount_str = f"{trans.amount:.2f}" if trans.amount != 0 else "0.00"
            trans_text += f"• {trans.created_at.strftime('%d.%m %H:%M')} | {username} | {trans.type} | {amount_str} ₽\n  _{trans.description}_\n\n"

        if not transactions:
            trans_text += "Транзакций нет."

        # Клавиатура навигации
        keyboard = []
        if page > 1:
            keyboard.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"transactions_page_{page-1}"))
        if page < total_pages:
            keyboard.append(InlineKeyboardButton(text="➡️ Далее", callback_data=f"transactions_page_{page+1}"))
        keyboard.append(InlineKeyboardButton(text="🔙 Назад к платежам", callback_data="admin_payments"))

        reply_markup = InlineKeyboardMarkup(inline_keyboard=[keyboard]) if keyboard else None

        await message.answer(markdown_to_html(trans_text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при получении транзакций: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при загрузке транзакций."), parse_mode="HTML")
    finally:
        session.close()


@admin_router.callback_query(lambda c: c.data.startswith("transactions_page_"))
async def transactions_page_callback(c: types.CallbackQuery):
    """Обработчик навигации по страницам транзакций."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        page = int(c.data.split("_")[2])
        await show_transactions_page(c.message, page)
    except ValueError:
        await c.answer("Неверная страница")
    await c.answer()


# ═══════════════════════════════════════════════════════════════
# 👥 УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_users")
async def admin_users_callback(c: types.CallbackQuery):
    """Обработчик callback Управление пользователями."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    await show_users_menu(c.message)
    await c.answer()


async def show_users_menu(message: types.Message):
    """Показать меню управления пользователями."""
    text = "👥 *Управление пользователями*\n\nВыберите действие:"

    keyboard = [
        [InlineKeyboardButton(text="📋 Список пользователей", callback_data="admin_user_list")],
        [InlineKeyboardButton(text="🔙 Назад в профиль", callback_data="back_to_profile")]
    ]

    reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
    await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)


@admin_router.callback_query(lambda c: c.data == "admin_user_list")
async def admin_user_list_callback(c: types.CallbackQuery):
    """Обработчик callback Список пользователей."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    # Показать список пользователей, страница 1
    await show_users_page(c.message, 1)
    await c.answer()


async def show_users_page(message: types.Message, page: int):
    """Показать страницу списка пользователей."""
    session = SessionLocal()
    try:
        users_per_page = 10
        offset = (page - 1) * users_per_page

        # Получить пользователей с пагинацией
        users = session.query(User).options(selectinload(User.tariff)).order_by(User.created_at.desc()).offset(offset).limit(users_per_page).all()
        total_users = session.query(User).count()
        total_pages = (total_users + users_per_page - 1) // users_per_page

        if page < 1 or page > total_pages:
            page = 1

        if not users:
            await message.answer(markdown_to_html("👥 *Пользователи (страница {page}/{total_pages})*\n\nПользователей нет."), parse_mode="HTML")
            return

        # Заголовок страницы
        header_text = f"👥 *Пользователи (страница {page}/{total_pages})*"
        await message.answer(markdown_to_html(header_text), parse_mode="HTML")

        # Отправить карточку для каждого пользователя
        for user in users:
            tariff_name = user.tariff.name if user.tariff else "Нет"
            blocked_status = "🚫 Заблокирован" if user.blocked else "✅ Активен"
            admin_status = "👑 Администратор" if user.is_admin else "👤 Обычный пользователь"

            user_text = f"""
👤 *Карточка пользователя*

🆔 ID: {user.telegram_id}
🚀 Тариф: {tariff_name}
💰 Кредиты: {user.credits:.2f}
📅 Регистрация: {user.created_at.strftime('%d.%m.%Y')}
📊 Статус: {blocked_status}
👑 Роль: {admin_status}
"""

            # Кнопки для пользователя
            admin_button_text = "👑 Снять админа" if user.is_admin else "👑 Назначить админом"
            keyboard = [
                [InlineKeyboardButton(text="Подробно", callback_data=f"user_details_{user.id}")],
                [InlineKeyboardButton(text="🚫 Блок/Разблок", callback_data=f"toggle_block_{user.id}")],
                [InlineKeyboardButton(text=admin_button_text, callback_data=f"toggle_admin_{user.id}")]
            ]

            reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
            await message.answer(markdown_to_html(user_text), parse_mode="HTML", reply_markup=reply_markup)

        # Клавиатура навигации
        nav_keyboard = []
        if page > 1:
            nav_keyboard.append(InlineKeyboardButton(text="⬅️ Назад", callback_data=f"users_page_{page-1}"))
        if page < total_pages:
            nav_keyboard.append(InlineKeyboardButton(text="➡️ Далее", callback_data=f"users_page_{page+1}"))
        nav_keyboard.append(InlineKeyboardButton(text="🔙 Назад к управлению", callback_data="admin_users"))

        nav_reply_markup = InlineKeyboardMarkup(inline_keyboard=[nav_keyboard]) if nav_keyboard else None
        await message.answer(markdown_to_html("Навигация:"), parse_mode="HTML", reply_markup=nav_reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при получении списка пользователей: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при загрузке пользователей."), parse_mode="HTML")
    finally:
        session.close()


@admin_router.callback_query(lambda c: c.data.startswith("users_page_"))
async def users_page_callback(c: types.CallbackQuery):
    """Обработчик навигации по страницам пользователей."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        page = int(c.data.split("_")[2])
        await show_users_page(c.message, page)
    except ValueError:
        await c.answer("Неверная страница")
    await c.answer()


@admin_router.callback_query(lambda c: c.data.startswith("user_details_"))
async def user_details_callback(c: types.CallbackQuery):
    """Обработчик просмотра деталей пользователя."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        user_id = int(c.data.split("_")[2])
        session = SessionLocal()
        user = session.query(User).options(selectinload(User.tariff)).filter(User.id == user_id).first()
        session.close()

        if not user:
            await c.message.answer(markdown_to_html("⚠️ Пользователь не найден."), parse_mode="HTML")
            return

        await show_user_details(c.message, user)
    except ValueError:
        await c.answer("Неверный ID пользователя")
    await c.answer()


async def show_user_details(message: types.Message, user: User):
    """Показать детальную информацию о пользователе."""
    session = SessionLocal()
    try:
        # Получить статистику транзакций
        total_transactions = session.query(Transaction).filter(Transaction.user_id == user.id).count()
        total_spent = sum(t.amount for t in session.query(Transaction).filter(Transaction.user_id == user.id, Transaction.amount > 0).all())
        total_earned = sum(abs(t.amount) for t in session.query(Transaction).filter(Transaction.user_id == user.id, Transaction.amount < 0).all())

        # Получить последние транзакции
        recent_transactions = session.query(Transaction).filter(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(5).all()

        tariff_name = user.tariff.name if user.tariff else "Нет"
        blocked_status = "🚫 Заблокирован" if user.blocked else "✅ Активен"
        admin_status = "👑 Администратор" if user.is_admin else "👤 Обычный пользователь"

        details_text = f"""
👤 *Детали пользователя*

🆔 *ID:* {user.telegram_id}
📊 *Статус:* {blocked_status}
👑 *Роль:* {admin_status}
💰 *Баланс кредитов:* {user.credits:.2f}
🚀 *Тариф:* {tariff_name}
📅 *Регистрация:* {user.created_at.strftime('%d.%m.%Y %H:%M')}

📈 *Статистика:*
• Всего транзакций: {total_transactions}
• Потрачено: {total_spent:.2f} ₽
• Заработано: {total_earned:.2f} ₽

💳 *Последние транзакции:*
"""

        for trans in recent_transactions:
            details_text += f"• {trans.created_at.strftime('%d.%m %H:%M')} | {trans.type} | {trans.amount:.2f} ₽\n  _{trans.description}_\n"

        if not recent_transactions:
            details_text += "Транзакций нет."

        # Кнопка для назначения/снятия админа
        admin_button_text = "👑 Снять админа" if user.is_admin else "👑 Назначить админом"
        admin_callback = f"toggle_admin_{user.id}"

        keyboard = [
            [InlineKeyboardButton(text="🚫 Блок/Разблок", callback_data=f"toggle_block_{user.id}")],
            [InlineKeyboardButton(text=admin_button_text, callback_data=admin_callback)],
            [InlineKeyboardButton(text="🔙 Назад к списку", callback_data="admin_user_list")]
        ]

        reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
        await message.answer(markdown_to_html(details_text), parse_mode="HTML", reply_markup=reply_markup)

    except Exception as e:
        logger.error(f"Ошибка при получении деталей пользователя: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при загрузке деталей."), parse_mode="HTML")
    finally:
        session.close()


@admin_router.callback_query(lambda c: c.data.startswith("toggle_block_"))
async def toggle_block_callback(c: types.CallbackQuery):
    """Обработчик блокировки/разблокировки пользователя."""
    logger.info(f"Toggle block callback triggered by user {c.from_user.id} with data: {c.data}")
    if not is_admin_check(c.from_user.id):
        logger.warning(f"Access denied for user {c.from_user.id} in toggle_block")
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        user_id = int(c.data.split("_")[2])
        logger.info(f"Attempting to toggle block for user_id {user_id}")
        session = SessionLocal()
        user = session.query(User).filter(User.id == user_id).first()

        if not user:
            logger.error(f"User with id {user_id} not found in DB")
            await c.message.answer(markdown_to_html("⚠️ Пользователь не найден."), parse_mode="HTML")
            session.close()
            return

        logger.info(f"User found: {user.telegram_id}, current blocked: {user.blocked}, is_admin: {user.is_admin}")

        # Нельзя заблокировать админа
        if user.is_admin:
            logger.warning(f"Attempted to block admin user {user.telegram_id}")
            await c.message.answer(markdown_to_html("⚠️ Нельзя заблокировать администратора."), parse_mode="HTML")
            session.close()
            return

        user.blocked = not user.blocked
        session.commit()
        session.close()

        status = "заблокирован" if user.blocked else "разблокирован"
        logger.info(f"User {user.telegram_id} {status}")
        await c.message.answer(markdown_to_html(f"✅ Пользователь {user.telegram_id} {status}."), parse_mode="HTML")

        # Обновить список пользователей
        await show_users_page(c.message, 1)

    except Exception as e:
        logger.error(f"Ошибка при изменении статуса блокировки: {e}")
        await c.message.answer(markdown_to_html("⚠️ Ошибка при изменении статуса."), parse_mode="HTML")
    await c.answer()


@admin_router.callback_query(lambda c: c.data.startswith("toggle_admin_"))
async def toggle_admin_callback(c: types.CallbackQuery):
    """Обработчик назначения/снятия админа."""
    logger.info(f"Toggle admin callback triggered by user {c.from_user.id} with data: {c.data}")
    if not is_admin_check(c.from_user.id):
        logger.warning(f"Access denied for user {c.from_user.id} in toggle_admin")
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    try:
        user_id = int(c.data.split("_")[2])
        logger.info(f"Attempting to toggle admin for user_id {user_id}")
        session = SessionLocal()
        user = session.query(User).filter(User.id == user_id).first()

        if not user:
            logger.error(f"User with id {user_id} not found in DB")
            await c.message.answer(markdown_to_html("⚠️ Пользователь не найден."), parse_mode="HTML")
            session.close()
            return

        logger.info(f"User found: {user.telegram_id}, current is_admin: {user.is_admin}")

        # Нельзя снять админа с самого себя
        if user.telegram_id == c.from_user.id:
            logger.warning(f"Attempted to demote self {user.telegram_id}")
            await c.message.answer(markdown_to_html("⚠️ Нельзя снять админа с самого себя."), parse_mode="HTML")
            session.close()
            return

        user.is_admin = not user.is_admin
        session.commit()
        session.close()

        status = "назначен админом" if user.is_admin else "снят с админа"
        logger.info(f"User {user.telegram_id} {status}")
        await c.message.answer(markdown_to_html(f"✅ Пользователь {user.telegram_id} {status}."), parse_mode="HTML")

        # Обновить детали пользователя
        await show_user_details(c.message, user)

    except Exception as e:
        logger.error(f"Ошибка при изменении статуса админа: {e}")
        await c.message.answer(markdown_to_html("⚠️ Ошибка при изменении статуса."), parse_mode="HTML")
    await c.answer()


# ═══════════════════════════════════════════════════════════════
# 📈 АДМИН СТАТИСТИКА
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_stats")
async def admin_stats_callback(c: types.CallbackQuery):
    """Обработчик callback Админ статистика."""
    session = SessionLocal()
    try:
        if not is_admin_check(c.from_user.id):
            await c.message.answer(markdown_to_html("🚫 Доступ запрещен. Эта функция только для админов."), parse_mode="HTML")
            return

        total_users = session.query(User).count()
        total_transactions = session.query(Transaction).count()
        active_subscriptions = session.query(Subscription).filter(Subscription.active == True).count()
        total_credits = session.query(User).with_entities(User.credits).all()
        total_credits_sum = sum(c[0] for c in total_credits)

        stats_text = f"""
📈 *Админ статистика*

👥 *Пользователи:* {total_users}
💳 *Транзакции:* {total_transactions}
📋 *Активные подписки:* {active_subscriptions}
💰 *Общий баланс кредитов:* {total_credits_sum:.2f}
"""
        await c.message.answer(markdown_to_html(stats_text), parse_mode="HTML", reply_markup=persistent_keyboard)
    except Exception as e:
        logger.error(f"Ошибка в admin_stats_callback: {e}")
        await c.message.answer(markdown_to_html("⚠️ Произошла ошибка при получении статистики."), parse_mode="HTML")
    finally:
        session.close()
    await c.answer()


# ═══════════════════════════════════════════════════════════════
# 📢 МАССОВЫЕ СООБЩЕНИЯ
# ═══════════════════════════════════════════════════════════════

@admin_router.callback_query(lambda c: c.data == "admin_mass_messaging")
async def admin_mass_messaging_callback(c: types.CallbackQuery):
    """Обработчик callback Массовые сообщения."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    await show_mass_messaging_menu(c.message)
    await c.answer()


async def show_mass_messaging_menu(message: types.Message):
    """Показать меню массовых сообщений."""
    text = "📢 *Массовые сообщения*\n\nВыберите группу получателей:"

    keyboard = [
        [InlineKeyboardButton(text="👥 Всем пользователям", callback_data="broadcast_all")],
        [InlineKeyboardButton(text="⭐ Пользователям с тарифом", callback_data="broadcast_premium")],
        [InlineKeyboardButton(text="🆓 Бесплатным пользователям", callback_data="broadcast_free")],
        [InlineKeyboardButton(text="🔙 Назад в профиль", callback_data="back_to_profile")]
    ]

    reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
    await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)


@admin_router.callback_query(lambda c: c.data.startswith("broadcast_"))
async def broadcast_callback(c: types.CallbackQuery):
    """Обработчик выбора группы для рассылки."""
    if not is_admin_check(c.from_user.id):
        await c.message.answer(markdown_to_html("🚫 Доступ запрещен."), parse_mode="HTML")
        return

    group = c.data.split("_")[1]
    pending_broadcasts[c.from_user.id] = {'group': group, 'text': None}
    await c.message.answer(markdown_to_html(f"📝 Введите текст сообщения для рассылки группе '{group}':"), parse_mode="HTML")
    await c.answer()


# Обработчик текстовых сообщений для админов (для ввода сообщения рассылки и настроек)
@admin_router.message(lambda message: is_admin_check(message.from_user.id) and message.text and (message.from_user.id in pending_broadcasts or message.from_user.id in pending_settings_input))
async def handle_admin_message(message: types.Message):
    """Обработчик сообщений от админов для массовой рассылки и ввода настроек."""
    user_id = message.from_user.id
    text = message.text.strip()
    logger.info(f"Admin message received from user {user_id}: '{text}'")
    if text.startswith("/"):
        logger.info(f"Ignoring command from admin {user_id}")
        return  # Игнорируем команды

    if user_id in pending_broadcasts and pending_broadcasts[user_id]['text'] is None:
        pending_broadcasts[user_id]['text'] = text
        group = pending_broadcasts[user_id]['group']
        logger.info(f"Broadcast text set for user {user_id}, group: {group}, text: '{text}'")
        await show_broadcast_confirmation(message, text, group)
    elif user_id in pending_settings_input:
        setting_id = pending_settings_input.pop(user_id)
        logger.info(f"Processing manual setting input for user {user_id}, setting_id: {setting_id}, value: '{text}'")
        await process_manual_setting_input(message, setting_id, text)
    else:
        logger.info(f"No pending input for admin {user_id}, ignoring message")
        # Не ожидаем ввод, игнорируем
        pass


async def show_broadcast_confirmation(message: types.Message, broadcast_text: str, group: str):
    """Показать подтверждение рассылки."""
    text = f"📢 *Подтверждение рассылки*\n\nГруппа: {group}\nСообщение:\n{broadcast_text}\n\nВы уверены?"

    keyboard = [
        [InlineKeyboardButton(text="✅ Отправить", callback_data=f"confirm_broadcast_{group}")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data="cancel_broadcast")]
    ]

    reply_markup = InlineKeyboardMarkup(inline_keyboard=keyboard)
    await message.answer(markdown_to_html(text), parse_mode="HTML", reply_markup=reply_markup)


@admin_router.callback_query(lambda c: c.data == "cancel_broadcast")
async def cancel_broadcast_callback(c: types.CallbackQuery):
    """Обработчик отмены рассылки."""
    if not is_admin_check(c.from_user.id):
        return

    user_id = c.from_user.id
    if user_id in pending_broadcasts:
        pending_broadcasts.pop(user_id)
    await c.message.answer(markdown_to_html("❌ Рассылка отменена."), parse_mode="HTML")
    await c.answer()


@admin_router.callback_query(lambda c: c.data.startswith("confirm_broadcast_"))
async def confirm_broadcast_callback(c: types.CallbackQuery):
    """Обработчик подтверждения рассылки."""
    if not is_admin_check(c.from_user.id):
        return

    group = c.data.split("_")[2]
    user_id = c.from_user.id
    if user_id in pending_broadcasts and pending_broadcasts[user_id]['group'] == group:
        broadcast_text = pending_broadcasts[user_id]['text']
        pending_broadcasts.pop(user_id)
        await start_broadcast(c.message, broadcast_text, group)
    else:
        await c.message.answer(markdown_to_html("⚠️ Ошибка: данные рассылки не найдены."), parse_mode="HTML")
    await c.answer()


async def process_manual_setting_input(message: types.Message, setting_id: int, value: str):
    """Обработка ручного ввода значения настройки."""
    session = SessionLocal()
    try:
        setting = session.query(Setting).filter(Setting.id == setting_id).first()
        if setting:
            setting.value = value
            session.commit()
            await message.answer(markdown_to_html(f"✅ Значение настройки **{setting.key}** обновлено на: `{value}`"), parse_mode="HTML")
        else:
            await message.answer(markdown_to_html("⚠️ Настройка не найдена."), parse_mode="HTML")
        session.close()
        await show_settings_menu(message)
    except Exception as e:
        logger.error(f"Ошибка при установке значения настройки: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при сохранении."), parse_mode="HTML")
    finally:
        session.close()


async def start_broadcast(message: types.Message, broadcast_text: str, group: str):
    """Начать рассылку сообщений."""
    logger.info(f"Starting broadcast to group '{group}' with text: '{broadcast_text[:50]}...'")
    session = SessionLocal()
    try:
        if group == "all":
            users = session.query(User).filter(User.blocked == False).all()
            logger.info(f"Query for 'all': found {len(users)} unblocked users")
        elif group == "premium":
            users = session.query(User).filter(User.tariff_id.isnot(None), User.blocked == False).all()
            logger.info(f"Query for 'premium': found {len(users)} users with tariff")
        elif group == "free":
            users = session.query(User).filter(User.tariff_id.is_(None), User.blocked == False).all()
            logger.info(f"Query for 'free': found {len(users)} users without tariff")
        else:
            users = []
            logger.warning(f"Unknown group '{group}', no users selected")

        total = len(users)
        if total == 0:
            logger.warning(f"No users found for broadcast to group '{group}'")
            await message.answer(markdown_to_html("👥 Нет пользователей в выбранной группе."), parse_mode="HTML")
            return

        logger.info(f"Broadcast starting: {total} users to send to")
        # Отправить сообщение о начале
        progress_msg = await message.answer(markdown_to_html(f"📤 Начинаю рассылку... 0/{total}"), parse_mode="HTML")

        sent = 0
        failed = 0
        rate_limit_hits = 0

        for user in users:
            logger.debug(f"Attempting to send broadcast to user {user.telegram_id} (blocked: {user.blocked}, tariff_id: {user.tariff_id})")
            try:
                await message.bot.send_message(chat_id=user.telegram_id, text=broadcast_text, parse_mode="HTML")
                logger.debug(f"Broadcast sent successfully to user {user.telegram_id}")
                sent += 1
            except Exception as e:
                logger.error(f"Failed to send broadcast to user {user.telegram_id}: {type(e).__name__}: {e}")
                failed += 1
                if "Too Many Requests" in str(e) or "rate limit" in str(e).lower():
                    rate_limit_hits += 1
                    logger.warning(f"Rate limit hit for user {user.telegram_id}, sleeping 1s")
                    # Увеличить задержку при rate limit
                    await asyncio.sleep(1.0)

            # Обновляем прогресс каждые 10 отправок
            if sent % 10 == 0 or sent == total:
                await progress_msg.edit_text(markdown_to_html(f"📤 Рассылка... {sent}/{total} (ошибок: {failed}, rate limits: {rate_limit_hits})"), parse_mode="HTML")

            # Задержка для избежания rate limit (30 msg/sec max)
            await asyncio.sleep(0.05)

        logger.info(f"Broadcast completed: sent {sent}, failed {failed}, rate limits {rate_limit_hits}")
        await progress_msg.edit_text(markdown_to_html(f"✅ Рассылка завершена! Отправлено: {sent}, ошибок: {failed}"), parse_mode="HTML")

    except Exception as e:
        logger.error(f"Error during broadcast: {type(e).__name__}: {e}")
        await message.answer(markdown_to_html("⚠️ Ошибка при рассылке."), parse_mode="HTML")
    finally:
        session.close()