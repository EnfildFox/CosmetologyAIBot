from .database import SyncSessionLocal as SessionLocal
from .models import User, Service, Subscription, Transaction, Tariff, Pricing
from datetime import datetime, date
import logging
import asyncio
from aiocache import cached, Cache
from aiocache.serializers import JsonSerializer

logger = logging.getLogger('cosmetology_bot')

# Словарь с ценами услуг в кредитах
SERVICE_PRICES = {
    'text': 10,
    'photo': 20,
    'analysis': 20,
    'post': 30
}


def reset_daily_quotas(user):
    """Сбрасывает дневные квоты, если прошел день."""
    today = date.today()
    if user.last_reset_date.date() < today:
        user.used_total_today = 0
        user.last_reset_date = datetime.utcnow()


def get_service_type(service_name):
    """Преобразует имя сервиса в тип для квот."""
    mapping = {
        'text_diagnosis': 'text',
        'photo_analysis': 'photo',
        'document_analysis': 'analysis',
        'post_generation': 'post',
        'advanced_analysis': 'analysis'
    }
    return mapping.get(service_name, service_name)


@cached(cache=Cache.MEMORY, ttl=60, serializer=JsonSerializer(), key="get_user_{user_id}")
async def get_user_async(user_id):
    """Асинхронное получение пользователя с кэшированием."""
    session = SessionLocal()
    try:
        user = session.query(User).filter(User.telegram_id == user_id).first()
        if not user:
            # Создать нового пользователя с дефолтным тарифом 'test'
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            if not test_tariff:
                logger.error("Тариф 'test' не найден в базе данных")
                return None
            user = User(
                telegram_id=user_id,
                tariff_id=test_tariff.id,
                used_total_today=0,
                last_reset_date=datetime.utcnow()
            )
            session.add(user)
            session.commit()
            logger.info(f"Создан новый пользователь {user_id} с тарифом 'test'")
        return user
    finally:
        session.close()

async def check_access(user_id, service_name):
    """
    Проверяет доступ к сервису по тарифу и квотам, или по кредитам.
    """
    session = SessionLocal()
    try:
        logger.info(f"Проверка доступа для пользователя {user_id} к сервису {service_name}")

        # Получить пользователя
        user = session.query(User).filter(User.telegram_id == user_id).first()
        if not user:
            # Создать нового пользователя с дефолтным тарифом 'test'
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            if not test_tariff:
                logger.error("Тариф 'test' не найден в базе данных")
                return False
            user = User(
                telegram_id=user_id,
                tariff_id=test_tariff.id,
                used_total_today=0,
                last_reset_date=datetime.utcnow()
            )
            session.add(user)
            session.commit()
            logger.info(f"Создан новый пользователь {user_id} с тарифом 'test'")

        if user.blocked:
            return False

        service_type = get_service_type(service_name)

        # Сбросить дневные квоты, если нужно (только для платных тарифов)
        if user.tariff and user.tariff.name != 'test':
            reset_daily_quotas(user)

        # Проверить лимиты тарифа (включая тестовый период)
        if user.tariff:
            tariff_limit = user.tariff.total_requests
            if tariff_limit == 'unlim':
                logger.info(f"Пользователь {user_id} имеет безлимитный доступ через тариф")
                return True
            elif isinstance(tariff_limit, int):
                if user.tariff.name == 'test':
                    used_tariff = user.total_requests
                    limit = 10  # Однократный лимит для пробного периода
                else:
                    used_tariff = user.used_total_today
                    limit = tariff_limit
                if used_tariff < limit:
                    logger.info(f"Пользователь {user_id} имеет доступ через тариф: осталось {limit - used_tariff} из {limit}")
                    return True
                else:
                    logger.warning(f"Пользователь {user_id} превысил лимиты тарифа: использовано {used_tariff} из {limit}")

        # Если лимиты тарифа превышены, проверить кредиты
        price = SERVICE_PRICES.get(service_type)
        if price and user.credits >= price:
            logger.info(f"Пользователь {user_id} имеет достаточно кредитов для {service_type}: {user.credits} >= {price}")
            return True

        logger.warning(f"Пользователь {user_id} не имеет доступа к {service_name}: лимиты тарифа и подписки превышены и недостаточно кредитов")
        return False
    finally:
        session.close()


async def deduct_credits(user_id, service_name):
    """
    Списывает квоты или кредиты за использование сервиса.
    """
    session = SessionLocal()
    try:
        logger.info(f"Начало deduct_credits для {user_id}, service_name {service_name}")

        # Получить пользователя
        user = session.query(User).filter_by(telegram_id=user_id).first()
        if not user:
            raise ValueError("User not found")

        service_type = get_service_type(service_name)
        logger.info(f"service_type {service_type}")

        # Mapping полей used
        used_field_mapping = {
            'text': 'used_text_today',
            'photo': 'used_photo',
            'post': 'used_post',
            'analysis': 'used_analysis'
        }
        used_field = used_field_mapping.get(service_type)
        logger.info(f"used_field {used_field}")

        # Сбросить дневные квоты, если нужно (только для платных тарифов)
        if user.tariff and user.tariff.name != 'test':
            reset_daily_quotas(user)

        # Проверить лимиты тарифа (включая тестовый период)
        if user.tariff:
            tariff_limit = user.tariff.total_requests
            logger.info(f"tariff_limit {tariff_limit}")
            if tariff_limit == 'unlim':
                # Безлимит, ничего не списывать
                transaction = Transaction(
                    user_id=user.id,
                    amount=0,
                    type="tariff_usage",
                    description=f"Использование безлимита тарифа"
                )
                session.add(transaction)
                session.commit()
                logger.info(f"Безлимит, транзакция создана")
                return
            elif isinstance(tariff_limit, int):
                if user.tariff.name == 'test':
                    used_tariff = user.total_requests
                    limit = 10  # Однократный лимит для пробного периода
                else:
                    used_tariff = user.used_total_today
                    limit = tariff_limit
                logger.info(f"used_tariff {used_tariff}, limit {limit}")
                if used_tariff < limit:
                    # Списать лимит тарифа
                    if user.tariff.name == 'test':
                        user.total_requests = used_tariff + 1
                    else:
                        user.used_total_today = used_tariff + 1
                    logger.info(f"setattr done, new used {used_tariff + 1}")

                    # Создать транзакцию
                    transaction = Transaction(
                        user_id=user.id,
                        amount=0,
                        type="tariff_usage",
                        description=f"Использование лимита тарифа"
                    )
                    session.add(transaction)
                    session.commit()
                    logger.info(f"Лимит списан, commit done")
                    return

        # Если лимиты тарифа превышены, списать кредиты
        price = SERVICE_PRICES.get(service_type)
        logger.info(f"price {price}")
        if not price:
            raise ValueError("Price not found for service")

        if user.credits < price:
            raise ValueError("Insufficient credits")

        user.credits -= price
        logger.info(f"credits after deduct {user.credits}")

        # Создать транзакцию
        transaction = Transaction(
            user_id=user.id,
            amount=-price,
            type="credit_usage",
            description=f"Использование сервиса {service_name}"
        )
        session.add(transaction)
        session.commit()
        logger.info(f"Кредиты списаны, commit done")
    except Exception as e:
        logger.error(f"Ошибка в deduct_credits: {e}")
        session.rollback()
    finally:
        session.close()


def successful_payment(user_id, amount, payment_type, description):
    """
    Обновляет баланс пользователя и записывает транзакцию.
    """
    session = SessionLocal()
    try:
        # Получить пользователя
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            raise ValueError("User not found")

        # Обновить кредиты
        user.credits += amount

        # Создать транзакцию
        transaction = Transaction(
            user_id=user_id,
            amount=amount,
            type=payment_type,
            description=description
        )
        session.add(transaction)
        session.commit()
    finally:
        session.close()