"""
Main module for Cosmetology AI Bot.

Этот модуль является точкой входа для Telegram бота косметологии.
Он инициализирует все компоненты, настраивает базу данных,
запускает планировщик задач и начинает polling сообщений.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import asyncio
from aiogram import Bot, Dispatcher
from config import Config
from src.database import SyncSessionLocal as SessionLocal, sync_engine as engine, init_db
from config.logging_config import setup_logging
from src.handlers import router
from src.admin_handlers import admin_router
import logging
from src.models import Base, Subscription
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from datetime import datetime

logger = logging.getLogger('cosmetology_bot')

async def deactivate_expired_subscriptions():
    """
    Деактивирует подписки пользователей с истекшим сроком действия.

    Эта функция выполняется ежедневно в полночь планировщиком задач.
    Она находит все активные подписки, у которых end_date меньше текущего времени,
    и устанавливает их статус как неактивные.

    Логирует количество деактивированных подписок для мониторинга.
    """
    session = SessionLocal()
    try:
        expired_subscriptions = session.query(Subscription).filter(
            Subscription.end_date < datetime.utcnow(),
            Subscription.active == True
        ).all()
        for sub in expired_subscriptions:
            sub.active = False
        session.commit()
        logger.info(f"Деактивировано {len(expired_subscriptions)} подписок")
    except Exception as e:
        logger.error(f"Ошибка при деактивации подписок: {e}")
        session.rollback()
    finally:
        session.close()

async def main():
    """
    Главная асинхронная функция для запуска Telegram бота.

    Выполняет последовательную инициализацию всех компонентов системы:
    1. Настраивает систему логирования
    2. Создает таблицы базы данных (если не существуют)
    3. Проверяет корректность конфигурации
    4. Запускает планировщик для автоматической деактивации подписок
    5. Инициализирует бота и диспетчера Aiogram
    6. Регистрирует обработчики сообщений
    7. Начинает polling для получения обновлений от Telegram

    В случае ошибки логирует ее и выбрасывает исключение для завершения программы.
    """
    try:
        # Настройка логирования
        setup_logging()

        # Создание таблиц базы данных
        Base.metadata.create_all(bind=engine)
        # Инициализация начальными данными
        init_db()
        logger.info("База данных настроена")

        # Валидация конфигурации
        Config.validate()

        # Настройка планировщика задач
        scheduler = AsyncIOScheduler()
        scheduler.add_job(deactivate_expired_subscriptions, 'cron', hour=0, minute=0)
        scheduler.start()
        logger.info("Планировщик задач запущен")

        # Инициализация бота и диспетчера
        bot = Bot(token=Config.TELEGRAM_BOT_TOKEN)
        dp = Dispatcher()

        # Регистрация роутера с обработчиками
        dp.include_router(router)
        dp.include_router(admin_router)

        logger.info("Бот запущен и готов к работе")

        # Запуск polling для получения сообщений
        await dp.start_polling(bot)

    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())