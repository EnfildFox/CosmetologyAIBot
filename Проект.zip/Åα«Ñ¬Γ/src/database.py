from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from config.config import Config
from .models import Base
from .models import Tariff, Package, Pricing, Setting

# Async engine
if 'sqlite' in Config.DATABASE_URL:
    async_url = Config.DATABASE_URL.replace('sqlite://', 'sqlite+aiosqlite://')
else:
    async_url = Config.DATABASE_URL.replace('postgresql://', 'postgresql+asyncpg://')
async_engine = create_async_engine(async_url, echo=False)
AsyncSessionLocal = sessionmaker(async_engine, class_=AsyncSession, expire_on_commit=False)

# Sync engine for init
from sqlalchemy import create_engine
sync_engine = create_engine(Config.DATABASE_URL, echo=False)
SyncSessionLocal = sessionmaker(sync_engine, expire_on_commit=False)


def init_db():
    """Инициализация базы данных: создание таблиц и заполнение начальными данными."""
    print("Starting database initialization...")
    Base.metadata.create_all(bind=sync_engine)

    # Заполнение начальными данными
    session = SyncSessionLocal()
    try:
        # Проверяем, есть ли уже данные
        if session.query(Tariff).count() == 0:
            # Тарифы
            tariffs = [
                Tariff(name='test', price_monthly=0, total_requests=10),
                Tariff(name='basic', price_monthly=600, total_requests=25),
                Tariff(name='pro', price_monthly=1200, total_requests=50),
                Tariff(name='vip', price_monthly=1500, total_requests=1000)
            ]
            session.add_all(tariffs)
        else:
            # Обновляем существующий тестовый тариф
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            if test_tariff:
                test_tariff.total_requests = 10

        if session.query(Package).count() == 0:
            # Пакеты
            packages = [
                Package(name='Стартовый', credits=100, price=150),
                Package(name='Выгодный', credits=500, price=500)
            ]
            session.add_all(packages)

        if session.query(Pricing).count() == 0:
            # Расценки
            pricings = [
                Pricing(service_type='text', price_per_use=10),
                Pricing(service_type='photo', price_per_use=30),
                Pricing(service_type='analysis', price_per_use=25),
                Pricing(service_type='post', price_per_use=15),
                Pricing(service_type='advanced', price_per_use=40)
            ]
            session.add_all(pricings)

        if session.query(Setting).count() == 0:
            # Настройки параметров
            settings = [
                Setting(key='max_requests_per_user', value='100', description='Максимальное количество запросов на пользователя в день'),
                Setting(key='daily_limit_reset_hour', value='0', description='Час сброса дневных лимитов (0-23)'),
                Setting(key='ai_response_timeout', value='30', description='Таймаут ответа AI в секундах'),
                Setting(key='max_conversation_history', value='10', description='Максимальное количество сообщений в истории разговора'),
                Setting(key='enable_ai_logging', value='true', description='Включить логирование AI запросов'),
                Setting(key='max_file_size_mb', value='10', description='Максимальный размер файла в МБ')
            ]
            session.add_all(settings)

        session.commit()
    except Exception as e:
        session.rollback()
        print(f"Ошибка при инициализации БД: {e}")
    finally:
        session.close()
    print("Database initialization completed.")


if __name__ == "__main__":
    from .models import Tariff, Package, Pricing
    init_db()
    print("База данных инициализирована.")