from sqlalchemy import ForeignKey, create_engine, JSON
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from datetime import datetime
from typing import Optional


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = 'users'

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(unique=True)
    credits: Mapped[float] = mapped_column(default=0.0)
    is_admin: Mapped[bool] = mapped_column(default=False)
    blocked: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)

    # Новые поля для тарифов и квот
    tariff_id: Mapped[Optional[int]] = mapped_column(ForeignKey('tariffs.id'), nullable=True)
    used_total_today: Mapped[int] = mapped_column(default=0)
    last_reset_date: Mapped[datetime] = mapped_column(default=datetime.utcnow)

    # Поля для лимитов пакетов
    package_text_limit: Mapped[int] = mapped_column(default=0)
    package_photo_limit: Mapped[int] = mapped_column(default=0)
    package_post_limit: Mapped[int] = mapped_column(default=0)
    package_analysis_limit: Mapped[int] = mapped_column(default=0)
    used_package_text: Mapped[int] = mapped_column(default=0)
    used_package_photo: Mapped[int] = mapped_column(default=0)
    used_package_post: Mapped[int] = mapped_column(default=0)
    used_package_analysis: Mapped[int] = mapped_column(default=0)

    # Relationships
    tariff: Mapped[Optional["Tariff"]] = relationship("Tariff", back_populates="users")


class Tariff(Base):
    __tablename__ = 'tariffs'

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(unique=True)
    price_monthly: Mapped[float] = mapped_column()
    total_requests: Mapped[int] = mapped_column(default=10)  # Единый лимит запросов для всех типов

    # Relationships
    users: Mapped[list["User"]] = relationship("User", back_populates="tariff")


class Package(Base):
    __tablename__ = 'packages'

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    credits: Mapped[float] = mapped_column()  # Количество кредитов в пакете
    price: Mapped[float] = mapped_column()


class Pricing(Base):
    __tablename__ = 'pricings'

    id: Mapped[int] = mapped_column(primary_key=True)
    service_type: Mapped[str] = mapped_column(unique=True)  # 'text', 'photo', 'analysis', 'post', 'advanced'
    price_per_use: Mapped[float] = mapped_column()


# Старые модели для совместимости (можно удалить позже)
class Service(Base):
    __tablename__ = 'services'

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    price: Mapped[float] = mapped_column()
    description: Mapped[str] = mapped_column()


class Subscription(Base):
    __tablename__ = 'subscriptions'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    service_id: Mapped[int] = mapped_column(ForeignKey('services.id'))
    start_date: Mapped[datetime] = mapped_column()
    end_date: Mapped[datetime] = mapped_column()
    active: Mapped[bool] = mapped_column(default=True)


class Transaction(Base):
    __tablename__ = 'transactions'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    amount: Mapped[float] = mapped_column()
    type: Mapped[str] = mapped_column()
    description: Mapped[str] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)


class Conversation(Base):
    __tablename__ = 'conversations'

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey('users.id'))
    message_type: Mapped[str] = mapped_column()  # text/photo/document
    user_message: Mapped[str] = mapped_column()
    bot_response: Mapped[str] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column(default=datetime.utcnow)


class Setting(Base):
    __tablename__ = 'settings'

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(unique=True)
    value: Mapped[str] = mapped_column()
    description: Mapped[str] = mapped_column()
    updated_at: Mapped[datetime] = mapped_column(default=datetime.utcnow)