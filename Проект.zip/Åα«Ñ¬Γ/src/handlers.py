"""
Handlers module for Cosmetology AI Bot.

Этот модуль содержит все обработчики команд и сообщений
для Telegram бота в режиме чата. Включает логику для:
- Обработки команд (/start, /help, /menu, /profile)
- Единого обработчика сообщений (текст, фото, документы)
- Обработки платежей через Telegram Payments
- Интеграции с AI сервисами с поддержкой истории диалога
- Управления подписками и кредитами
"""

from aiogram import Router, types
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, LabeledPrice, ReplyKeyboardMarkup, KeyboardButton
from .ai_service import AIService
from .utils import (
    validate_text_input,
    sanitize_text,
    add_disclaimer,
    split_text,
    markdown_to_html,
    WELCOME_MESSAGE,
    ERROR_INVALID_TEXT,
    ERROR_UNSUPPORTED_FILE,
    ERROR_FILE_PROCESSING,
    ERROR_PHOTO_PROCESSING,
    ERROR_PDF_EXTRACTION,
    ERROR_DOCX_EXTRACTION,
    get_loading_message,
    is_admin_check
)
from .database import SyncSessionLocal as SessionLocal
from .models import User, Subscription, Transaction, Service, Tariff, Package
from .payment_utils import successful_payment, check_access, deduct_credits
from .admin_handlers import pending_broadcasts, pending_settings_input
from config.config import Config as config
import logging
import tempfile
import os
import json
import time
from datetime import datetime, timedelta

logger = logging.getLogger('cosmetology_bot')

router = Router()
ai_service = AIService()


# ═══════════════════════════════════════════════════════════════
# 🎨 КЛАВИАТУРЫ С EMOJI
# ═══════════════════════════════════════════════════════════════

# Постоянная клавиатура для всех ответов бота
persistent_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="👤 Профиль"), KeyboardButton(text="❓ Помощь")],
        [KeyboardButton(text="💬 Меню"), KeyboardButton(text="🔙 Назад в чат")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Клавиатура для покупки пакетов кредитов
buy_packages_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="🚀 Стартовый: 100 кредитов - 150 ₽", callback_data="buy_package_1")],
        [InlineKeyboardButton(text="💎 Выгодный: 500 кредитов - 500 ₽", callback_data="buy_package_2")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_chat")]
    ]
)

# Клавиатура для тарифа
buy_tariff_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="🌟 Базовый - 600 ₽/мес", callback_data="subscribe_basic"),
            InlineKeyboardButton(text="⭐ Про - 1200 ₽/мес", callback_data="subscribe_pro")
        ],
        [
            InlineKeyboardButton(text="🏆 VIP - 1500 ₽/мес", callback_data="subscribe_vip")
        ],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_chat")]
    ]
)


# ═══════════════════════════════════════════════════════════════
# 🚀 КОМАНДЫ
# ═══════════════════════════════════════════════════════════════

@router.message(Command("start"))
async def start_command(message: types.Message):
    """Обработчик команды /start с красивым приветствием."""
    # Создание пользователя с тестовым тарифом, если он не существует
    session = SessionLocal()
    try:
        user = session.query(User).filter(User.telegram_id == message.from_user.id).first()
        if not user:
            # Получаем тестовый тариф
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            if test_tariff:
                new_user = User(
                    telegram_id=message.from_user.id,
                    tariff_id=test_tariff.id
                )
                session.add(new_user)
                session.commit()
                logger.info(f"Создан новый пользователь {message.from_user.id} с тестовым тарифом")
            else:
                logger.error("Тестовый тариф не найден в базе данных")
    except Exception as e:
        logger.error(f"Ошибка при создании пользователя: {e}")
        session.rollback()
    finally:
        session.close()

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👤 Профиль", callback_data="profile")]
        ]
    )
    await message.answer(
        markdown_to_html(WELCOME_MESSAGE),
        parse_mode="HTML",
        reply_markup=persistent_keyboard
    )
    await message.answer(
        "Выберите действие:",
        reply_markup=keyboard
    )


@router.message(Command("menu"))
async def menu_command(message: types.Message):
    """Обработчик команды /menu."""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="👤 Профиль", callback_data="profile")]
        ]
    )
    await message.answer(
        markdown_to_html(WELCOME_MESSAGE),
        parse_mode="HTML",
        reply_markup=persistent_keyboard
    )
    await message.answer(
        "Выберите действие:",
        reply_markup=keyboard
    )


@router.message(Command("help"))
async def help_command(message: types.Message):
    """Обработчик команды /help."""
    help_text = """
❓ *Справка по боту*
═══════════════════════════════════

*Доступные команды:*
• /start - Запустить бота
• /menu - Показать приветственное сообщение
• /help - Показать эту справку
• /profile - Просмотр профиля и управление кредитами

*Как использовать бота:*

💬 *Режим чата*
Просто пишите сообщения, отправляйте фото или документы. AI запоминает контекст и дает последовательные ответы.

🔬 *Диагностика кожи*
Опишите проблему текстом, и AI проанализирует симптомы.

📸 *Анализ фото*
Отправьте фото проблемного участка кожи.

📋 *Анализ документов*
Загрузите медицинские документы для разбора.

🧠 *Вопросы и контент*
Задавайте любые вопросы по дерматологии и косметологии.

───────────────────────────────────
💬 *Начните диалог прямо сейчас!*
"""
    await message.answer(markdown_to_html(help_text), parse_mode="HTML", reply_markup=persistent_keyboard)








# ═══════════════════════════════════════════════════════════════
# 🔘 ОБРАБОТЧИКИ CALLBACK-КНОПОК
# ═══════════════════════════════════════════════════════════════


@router.message(Command("profile"))
async def profile_command(message: types.Message):
    """Обработчик команды /profile."""
    # Ignore messages from the bot itself
    if message.from_user.id == 7805791220:
        return
    session = SessionLocal()
    try:
        user = session.query(User).filter(User.telegram_id == message.from_user.id).first()
        if not user:
            # Получаем тестовый тариф
            test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
            if test_tariff:
                new_user = User(
                    telegram_id=message.from_user.id,
                    tariff_id=test_tariff.id
                )
                session.add(new_user)
                session.commit()
                user = new_user
                logger.info(f"Создан новый пользователь {message.from_user.id} с тестовым тарифом")
            else:
                logger.error("Тестовый тариф не найден в базе данных")
                await message.answer(markdown_to_html("Ошибка системы. Обратитесь в поддержку."), parse_mode="HTML")
                return

        is_admin = is_admin_check(message.from_user.id)
        logger.info(f"Profile command for user {message.from_user.id}, is_admin: {is_admin}")

        # Получаем транзакции для пакетов кредитов
        package_transactions = session.query(Transaction).filter(
            Transaction.user_id == user.id,
            Transaction.type == "package_purchase"
        ).order_by(Transaction.created_at.desc()).all()

        # Активная подписка
        active_subscription_text = "Нет активной подписки"
        subscription_limits = ""
        if user.tariff:
            tariff = user.tariff
            active_subscription_text = f"{tariff.name.capitalize()} (ежемесячно {tariff.price_monthly} ₽)"
            total_requests = tariff.total_requests
            used_total = user.used_total_today
            if total_requests == 'unlim':
                subscription_limits = "• Все сервисы: безлимит"
            elif isinstance(total_requests, int):
                subscription_limits = f"• Общий лимит запросов: {used_total}/{total_requests}"

        # Купленные пакеты кредитов
        packages_text = ""
        if package_transactions:
            packages_list = []
            for trans in package_transactions:
                packages_list.append(f"• {trans.description} ({trans.created_at.strftime('%d.%m.%Y')})")
            packages_text = "\n".join(packages_list)
        else:
            packages_text = "Нет купленных пакетов"

        # Источники лимитов (только от тарифа)
        if user.tariff:
            total_requests = user.tariff.total_requests
            used_total = user.used_total_today
            if total_requests == 'unlim':
                limits_text = "Все сервисы: безлимит (тариф)"
            elif isinstance(total_requests, int):
                limits_text = f"Общий лимит запросов: {used_total}/{total_requests} (тариф)"
            else:
                limits_text = "Нет лимитов"
        else:
            limits_text = "Нет лимитов"

        profile_text = f"""
👤 *Профиль пользователя*

💰 *Баланс кредитов:* {user.credits:.2f}

🚀 *Активная подписка:* {active_subscription_text}
{subscription_limits}

💎 *Купленные пакеты кредитов:*
{packages_text}

📊 *Источники лимитов:*
{limits_text}
"""

        # Динамическая клавиатура профиля
        keyboard_buttons = [
            [InlineKeyboardButton(text="💎 Купить пакеты кредитов", callback_data="buy_credits")],
            [InlineKeyboardButton(text="🚀 Оформить тариф", callback_data="buy_subscription")],
            [InlineKeyboardButton(text="📊 История транзакций", callback_data="my_history")]
        ]
        if is_admin:
            keyboard_buttons.append([InlineKeyboardButton(text="📈 Админ статистика", callback_data="admin_stats")])
            keyboard_buttons.append([InlineKeyboardButton(text="👥 Управление пользователями", callback_data="admin_users")])
            keyboard_buttons.append([InlineKeyboardButton(text=" Мониторинг платежей", callback_data="admin_payments")])
            keyboard_buttons.append([InlineKeyboardButton(text="📋 Просмотр логов", callback_data="admin_logs")])
            keyboard_buttons.append([InlineKeyboardButton(text="⚙️ Настройки параметров", callback_data="admin_settings")])
            keyboard_buttons.append([InlineKeyboardButton(text="📢 Массовые сообщения", callback_data="admin_mass_messaging")])
        keyboard_buttons.append([InlineKeyboardButton(text=" Назад в чат", callback_data="back_to_chat")])

        profile_keyboard = InlineKeyboardMarkup(inline_keyboard=keyboard_buttons)

        await message.answer(
            markdown_to_html(profile_text),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        await message.answer(
            "Выберите действие:",
            reply_markup=profile_keyboard
        )
    except Exception as e:
        logger.error(f"Ошибка в profile_command: {e}")
        await message.answer(markdown_to_html("⚠️ Произошла ошибка при получении профиля."), parse_mode="HTML")
    finally:
        session.close()


@router.callback_query(lambda c: c.data == "buy_credits")
async def buy_packages_callback(c: types.CallbackQuery):
    """Обработчик callback Купить пакеты."""
    buy_text = """
💰 *Покупка пакетов*

Выберите пакет для активации лимитов:
"""
    await c.message.answer(markdown_to_html(buy_text), parse_mode="HTML", reply_markup=persistent_keyboard)
    await c.message.answer("Выберите пакет:", reply_markup=buy_packages_keyboard)
    await c.answer()


@router.callback_query(lambda c: c.data == "buy_subscription")
async def buy_tariff_callback(c: types.CallbackQuery):
    """Обработчик callback Оформить тариф."""
    sub_text = """🚀 *Оформить тариф*

    **🌟 Базовый** - 600 ₽/мес
    • 📸 Фото: 5 анализов
    • 📝 Текст: 5 запросов
    • 🧠 База знаний: 10 запросов
    • 🔬 Анализ: 5 анализов

    **⭐ Про** - 1200 ₽/мес
    • 📝 Текст: *безлимит*
    • 📸 Фото: 10 анализов
    • 🧠 База знаний: 20 запросов
    • 🔬 Анализ: 10 анализов

    **🏆 VIP** - 1500 ₽/мес
    • *Все функции без ограничений*

    Выберите тариф:"""
    await c.message.answer(markdown_to_html(sub_text), parse_mode="HTML", reply_markup=persistent_keyboard)
    await c.message.answer("Выберите тариф:", reply_markup=buy_tariff_keyboard)
    await c.answer()


@router.callback_query(lambda c: c.data == "my_history")
async def my_history_callback(c: types.CallbackQuery):
    """Обработчик callback История транзакций."""
    session = SessionLocal()
    try:
        user = session.query(User).filter(User.telegram_id == c.from_user.id).first()
        if not user:
            await c.message.answer(markdown_to_html("👤 Пользователь не найден."), parse_mode="HTML")
            return

        transactions = session.query(Transaction).filter(Transaction.user_id == user.id).order_by(Transaction.created_at.desc()).limit(10).all()

        if not transactions:
            trans_text = "📭 История транзакций пуста"
        else:
            trans_text = "\n".join([f"• {t.created_at.strftime('%d.%m.%Y %H:%M')} - {t.type}: {t.amount:.2f} ({t.description})" for t in transactions])

        my_text = f"""
📊 *История транзакций*

{trans_text}
"""
        await c.message.answer(markdown_to_html(my_text), parse_mode="HTML", reply_markup=persistent_keyboard)
    except Exception as e:
        logger.error(f"Ошибка в my_history_callback: {e}")
        await c.message.answer(markdown_to_html("⚠️ Произошла ошибка при получении истории."), parse_mode="HTML")
    finally:
        session.close()
    await c.answer()




@router.callback_query(lambda c: c.data == "profile")
async def profile_callback(c: types.CallbackQuery):
    """Обработчик callback Профиль."""
    await profile_command(c.message)
    await c.answer()


@router.callback_query(lambda c: c.data == "back_to_chat")
async def back_to_chat_callback(c: types.CallbackQuery):
    """Обработчик callback Назад в чат."""
    await c.message.answer(markdown_to_html("💬 Продолжим наш диалог! Расскажите о вашей проблеме или задайте вопрос."), parse_mode="HTML", reply_markup=persistent_keyboard)
    await c.answer()


@router.callback_query(lambda c: c.data == "back_to_profile")
async def back_to_profile_callback(c: types.CallbackQuery):
    """Обработчик callback Назад в профиль."""
    await profile_command(c.message)
    await c.answer()


@router.callback_query(lambda c: c.data == "back_to_menu")
async def back_to_menu_callback(c: types.CallbackQuery):
    """Обработчик callback Назад в меню."""
    await menu_command(c.message)
    await c.answer()


@router.callback_query(lambda c: c.data == "back_to_start")
async def back_to_start_callback(c: types.CallbackQuery):
    """Обработчик callback Назад в начало."""
    await start_command(c.message)
    await c.answer()


@router.callback_query(lambda c: c.data.startswith("subscribe_"))
async def subscribe_callback(c: types.CallbackQuery):
    """Обработчик callback покупки тарифа."""
    data = c.data
    tariff_types = {
        "basic": {"name": "Базовый", "price": 600, "description": "🌟 Базовый тариф: 5📸 фото, 5📝 текста, 10✨ постов, 5🔬 анализов. Отличный выбор для регулярного использования!"},
        "pro": {"name": "Про", "price": 1200, "description": "⭐ Про тариф: 📝 текст безлим, 10📸 фото, 20✨ постов, 10🔬 анализов. Для профессионалов косметологии!"},
        "vip": {"name": "VIP", "price": 1500, "description": "🏆 VIP тариф: все функции без ограничений! Полный доступ ко всем возможностям AI-анализа кожи."}
    }

    sub_type = data.split("_")[1]
    if sub_type not in tariff_types:
        await c.answer("Неверный выбор тарифа")
        return

    tariff_info = tariff_types[sub_type]

    # Создаем инвойс для тарифа (на месяц)
    prices = [LabeledPrice(label=f"Тариф {tariff_info['name']} (1 месяц)", amount=int(tariff_info['price'] * 100))]

    provider_data = json.dumps({
        "receipt": {
            "items": [
                {
                    "description": f"Тариф {tariff_info['name']} (1 месяц)",
                    "quantity": "1.00",
                    "amount": {
                        "value": f"{tariff_info['price']:.2f}",
                        "currency": "RUB"
                    },
                    "vat_code": 1
                }
            ]
        }
    })

    await c.bot.send_invoice(
        chat_id=c.message.chat.id,
        title=f"Тариф {tariff_info['name']}",
        description=tariff_info['description'],
        payload=f"tariff_{sub_type}_{c.from_user.id}",
        provider_token="390540012:LIVE:84440",
        currency="RUB",
        prices=prices,
        provider_data=provider_data,
        start_parameter="buy_tariff",
        photo_url=None,
        photo_size=None,
        photo_width=None,
        photo_height=None,
        need_name=False,
        need_phone_number=False,
        need_email=True,
        need_shipping_address=False,
        send_phone_number_to_provider=False,
        send_email_to_provider=True,
        is_flexible=False
    )
    await c.answer()


@router.callback_query(lambda c: c.data.startswith("buy_package_"))
async def buy_package_callback(c: types.CallbackQuery):
    """Обработчик callback покупки пакета кредитов."""
    data = c.data
    session = SessionLocal()
    try:
        package_id = int(data.split("_")[2])
        package = session.query(Package).filter(Package.id == package_id).first()
        if not package:
            await c.answer("Пакет не найден")
            return

        # Создаем инвойс
        prices = [LabeledPrice(label=package.name, amount=int(package.price * 100))]  # В копейках

        provider_data = json.dumps({
            "receipt": {
                "items": [
                    {
                        "description": f"{package.name} ({package.credits} кредитов)",
                        "quantity": "1.00",
                        "amount": {
                            "value": f"{package.price:.2f}",
                            "currency": "RUB"
                        },
                        "vat_code": 1
                    }
                ]
            }
        })

        await c.bot.send_invoice(
            chat_id=c.message.chat.id,
            title=package.name,
            description=f"Активация {package.credits} кредитов",
            payload=f"package_{package_id}_{c.from_user.id}",
            provider_token="390540012:LIVE:84440",
            currency="RUB",
            prices=prices,
            provider_data=provider_data,
            start_parameter="buy_package",
            photo_url=None,
            photo_size=None,
            photo_width=None,
            photo_height=None,
            need_name=False,
            need_phone_number=False,
            need_email=True,
            need_shipping_address=False,
            send_phone_number_to_provider=False,
            send_email_to_provider=True,
            is_flexible=False
        )
    finally:
        session.close()
    await c.answer()


@router.pre_checkout_query()
async def pre_checkout_query_handler(pre_checkout_query: types.PreCheckoutQuery):
    """Обработчик pre_checkout_query для проверки платежа."""
    start_time = time.time()
    logger.info(f"Получен pre_checkout_query от пользователя {pre_checkout_query.from_user.id}")
    try:
        # Всегда подтверждаем, так как проверка уже сделана при создании инвойса
        await pre_checkout_query.answer(ok=True)
        duration = time.time() - start_time
        logger.info(f"pre_checkout_query обработан успешно за {duration:.3f} секунд")
    except Exception as e:
        logger.error(f"Ошибка в pre_checkout_query_handler: {e}")
        duration = time.time() - start_time
        logger.error(f"pre_checkout_query обработан с ошибкой за {duration:.3f} секунд")
        # В случае ошибки пытаемся ответить с ok=False, чтобы избежать таймаута
        try:
            await pre_checkout_query.answer(ok=False, error_message="Внутренняя ошибка сервера")
        except Exception as inner_e:
            logger.error(f"Не удалось ответить на pre_checkout_query: {inner_e}")


@router.message(lambda message: message.successful_payment)
async def successful_payment_handler(message: types.Message):
    """Обработчик успешного платежа."""
    payment = message.successful_payment
    payload = payment.invoice_payload

    if payload.startswith("package_"):
        # Парсим payload: package_{package_id}_{user_id}
        try:
            _, package_id, user_id = payload.split('_')
            package_id = int(package_id)
            user_id = int(user_id)
        except ValueError:
            logger.error(f"Неверный payload: {payload}")
            return

        session = SessionLocal()
        try:
            package = session.query(Package).filter(Package.id == package_id).first()
            if not package:
                logger.error(f"Пакет {package_id} не найден")
                await message.answer(markdown_to_html("❌ Пакет не найден. Обратитесь в поддержку."), parse_mode="HTML", reply_markup=persistent_keyboard)
                return

            # Получить пользователя
            user = session.query(User).filter(User.telegram_id == user_id).first()
            if not user:
                # Создание пользователя, если он не найден
                test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
                if test_tariff:
                    new_user = User(
                        telegram_id=user_id,
                        tariff_id=test_tariff.id
                    )
                    session.add(new_user)
                    session.commit()
                    user = new_user
                    logger.info(f"Создан новый пользователь {user_id} с тестовым тарифом при обработке платежа пакета")
                else:
                    logger.error("Тестовый тариф не найден в базе данных")
                    await message.answer(markdown_to_html("❌ Ошибка системы. Обратитесь в поддержку."), parse_mode="HTML", reply_markup=persistent_keyboard)
                    return

            # Добавить кредиты на баланс
            user.credits += package.credits

            # Создать транзакцию
            transaction = Transaction(
                user_id=user.id,
                amount=package.price,
                type="package_purchase",
                description=f"Покупка пакета {package.name} ({package.credits} кредитов)"
            )
            session.add(transaction)
            session.commit()

            await message.answer(
                markdown_to_html(f"💰 ✅ Платеж успешно обработан! На ваш баланс добавлено {package.credits} кредитов."),
                parse_mode="HTML",
                reply_markup=persistent_keyboard
            )
        except Exception as e:
            logger.error(f"Ошибка при обработке платежа пакета: {e}")
            await message.answer(
                markdown_to_html("❌ Произошла ошибка при обработке платежа. Обратитесь в поддержку."),
                parse_mode="HTML",
                reply_markup=persistent_keyboard
            )
        finally:
            session.close()
    elif payload.startswith("tariff_"):
        # Парсим payload: tariff_{tariff_type}_{user_id}
        try:
            _, tariff_type, user_id = payload.split('_')
            user_id = int(user_id)
        except ValueError:
            logger.error(f"Неверный payload: {payload}")
            return

        session = SessionLocal()
        try:
            tariff = session.query(Tariff).filter(Tariff.name == tariff_type).first()
            if not tariff:
                logger.error(f"Тариф {tariff_type} не найден")
                await message.answer(markdown_to_html("❌ Тариф не найден. Обратитесь в поддержку."), parse_mode="HTML", reply_markup=persistent_keyboard)
                return

            # Получить пользователя
            user = session.query(User).filter(User.telegram_id == user_id).first()
            if not user:
                # Создание пользователя, если он не найден
                test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()
                if test_tariff:
                    new_user = User(
                        telegram_id=user_id,
                        tariff_id=test_tariff.id
                    )
                    session.add(new_user)
                    session.commit()
                    user = new_user
                    logger.info(f"Создан новый пользователь {user_id} с тестовым тарифом при обработке платежа тарифа")
                else:
                    logger.error("Тестовый тариф не найден в базе данных")
                    await message.answer(markdown_to_html("❌ Ошибка системы. Обратитесь в поддержку."), parse_mode="HTML", reply_markup=persistent_keyboard)
                    return

            # Установить тариф пользователю
            user.tariff_id = tariff.id
            # Сбросить использованные квоты
            user.used_total_today = 0
            user.last_reset_date = datetime.utcnow()

            # Создать транзакцию
            transaction = Transaction(
                user_id=user.id,
                amount=tariff.price_monthly,
                type="tariff",
                description=f"Тариф {tariff.name} (1 месяц)"
            )
            session.add(transaction)
            session.commit()

            await message.answer(
                markdown_to_html(f"🚀 ✅ Тариф {tariff.name} успешно активирован!"),
                parse_mode="HTML",
                reply_markup=persistent_keyboard
            )
        except Exception as e:
            logger.error(f"Ошибка при обработке тарифа: {e}")
            await message.answer(
                markdown_to_html("❌ Произошла ошибка при активации тарифа. Обратитесь в поддержку."),
                parse_mode="HTML",
                reply_markup=persistent_keyboard
            )
        finally:
            session.close()
    else:
        logger.error(f"Неизвестный payload: {payload}")
        await message.answer(markdown_to_html("❌ Неизвестный тип платежа."), parse_mode="HTML", reply_markup=persistent_keyboard)


# ═══════════════════════════════════════════════════════════════
# 💬 ЕДИНЫЙ ОБРАБОТЧИК СООБЩЕНИЙ В РЕЖИМЕ ЧАТА
# ═══════════════════════════════════════════════════════════════

@router.message(lambda message: message.text and not message.text.startswith('/'))
async def handle_text_message(message: types.Message):
    """Единый обработчик текстовых сообщений в режиме чата."""
    user_id = message.from_user.id
    text = message.text.strip()

    # Обработка кнопок постоянной клавиатуры
    if text == "👤 Профиль":
        await profile_command(message)
        return
    elif text == "❓ Помощь":
        await help_command(message)
        return
    elif text == "💬 Меню":
        await menu_command(message)
        return
    elif text == "🔙 Назад в чат":
        await message.answer(markdown_to_html("💬 Продолжим наш диалог! Расскажите о вашей проблеме или задайте вопрос."), parse_mode="HTML", reply_markup=persistent_keyboard)
        return

    # Skip processing for admins in pending input states to allow admin_router to handle
    if is_admin_check(user_id) and (user_id in pending_broadcasts or user_id in pending_settings_input):
        return

    # Отправляем сообщение о загрузке сразу после получения запроса
    loading_msg = await message.answer(
        markdown_to_html("⏳ Пожалуйста, подождите, я обрабатываю ваш запрос..."),
        parse_mode="HTML",
        reply_markup=persistent_keyboard
    )

    text = sanitize_text(text)

    if not validate_text_input(text):
        await loading_msg.delete()
        await message.answer(
            markdown_to_html(ERROR_INVALID_TEXT),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        return

    # Проверка доступа (для текстовых запросов)
    if not await check_access(user_id, 'text_diagnosis'):
        await loading_msg.delete()
        await message.answer(
            markdown_to_html("Для использования чата необходимо приобрести кредиты или подписку."),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        await message.answer("Выберите пакет:", reply_markup=buy_packages_keyboard)
        return

    # Анализируем текст с учетом истории
    responses = await ai_service.analyze_text_problem(user_id, text)

    # Удаляем сообщение о загрузке
    await loading_msg.delete()

    # Отправляем ответ
    for response in responses:
        parts = split_text(response)
        for part in parts:
            await message.answer(markdown_to_html(part), parse_mode="HTML", reply_markup=persistent_keyboard)

    # Списываем кредиты, если ответ успешный
    if responses and not any("ошибка" in r.lower() or "извините" in r.lower() for r in responses):
        try:
            await deduct_credits(user_id, 'text_diagnosis')
        except Exception as e:
            logger.error(f"Ошибка при списании кредитов за чат: {e}")


# ═══════════════════════════════════════════════════════════════
# 📸 ОБРАБОТЧИКИ ФОТО
# ═══════════════════════════════════════════════════════════════

@router.message(lambda message: message.photo)
async def handle_photo_message(message: types.Message):
    """Обработчик фото сообщений в режиме чата."""
    user_id = message.from_user.id

    # Отправляем сообщение о загрузке сразу после получения запроса
    loading_msg = await message.answer(
        markdown_to_html("⏳ Пожалуйста, подождите, я обрабатываю ваш запрос..."),
        parse_mode="HTML",
        reply_markup=persistent_keyboard
    )

    # Проверка доступа
    if not await check_access(user_id, "photo_analysis"):
        await loading_msg.delete()
        await message.answer(
            markdown_to_html("Для анализа фото необходимо приобрести кредиты или подписку."),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        await message.answer("Выберите пакет:", reply_markup=buy_packages_keyboard)
        return

    # Получаем file_id фото
    photo = message.photo[-1]  # Самое большое разрешение
    file_id = photo.file_id

    try:
        # Получаем информацию о файле
        file_info = await message.bot.get_file(file_id)
        file_path = file_info.file_path
        # Скачиваем файл
        file = await message.bot.download_file(file_path)
        image_bytes = file.read()

    except Exception as e:
        logger.error(f"Ошибка при загрузке файла: {e}")
        await loading_msg.delete()
        await message.answer(
            markdown_to_html(ERROR_PHOTO_PROCESSING),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        return

    description = message.caption or "Фото кожи для анализа"
    responses = await ai_service.analyze_image(user_id, image_bytes, description)

    # Удаляем сообщение о загрузке
    try:
        await loading_msg.delete()
    except:
        pass

    # Отправляем ответ
    for response in responses:
        parts = split_text(response)
        for part in parts:
            await message.answer(markdown_to_html(part), parse_mode="HTML", reply_markup=persistent_keyboard)

    # Списываем кредиты
    try:
        await deduct_credits(user_id, "photo_analysis")
    except Exception as e:
        logger.error(f"Ошибка при списании кредитов за фото: {e}")


# ═══════════════════════════════════════════════════════════════
# 📄 ОБРАБОТЧИКИ ДОКУМЕНТОВ
# ═══════════════════════════════════════════════════════════════

@router.message(lambda message: message.document)
async def handle_document_message(message: types.Message):
    """Обработчик документов в режиме чата."""
    user_id = message.from_user.id

    # Отправляем сообщение о загрузке сразу после получения запроса
    loading_msg = await message.answer(
        markdown_to_html("⏳ Пожалуйста, подождите, я обрабатываю ваш запрос..."),
        parse_mode="HTML",
        reply_markup=persistent_keyboard
    )

    # Проверка доступа
    if not await check_access(user_id, "document_analysis"):
        await loading_msg.delete()
        await message.answer(
            markdown_to_html("Для анализа документов необходимо приобрести кредиты или подписку."),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )
        await message.answer("Выберите пакет:", reply_markup=buy_packages_keyboard)
        return

    document = message.document
    file_id = document.file_id
    file_name = document.file_name or "document"
    mime_type = document.mime_type

    # Определяем тип файла
    file_extension = os.path.splitext(file_name)[1].lower()

    if mime_type:
        if mime_type in ['image/png', 'image/jpeg'] or file_extension in ['.png', '.jpg', '.jpeg']:
            file_type = 'image'
        elif mime_type == 'application/pdf' or file_extension == '.pdf':
            file_type = 'pdf'
        elif mime_type == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' or file_extension == '.docx':
            file_type = 'docx'
        else:
            await loading_msg.delete()
            await message.answer(
                markdown_to_html(ERROR_UNSUPPORTED_FILE),
                parse_mode="HTML",
                reply_markup=persistent_keyboard
            )
            return
    else:
        # Если MIME не указан, используем расширение
        if file_extension in ['.png', '.jpg', '.jpeg']:
            file_type = 'image'
        elif file_extension == '.pdf':
            file_type = 'pdf'
        elif file_extension == '.docx':
            file_type = 'docx'
        else:
            await loading_msg.delete()
            await message.answer(
                markdown_to_html(ERROR_UNSUPPORTED_FILE),
                parse_mode="HTML"
            )
            return

    try:
        # Скачиваем файл во временную директорию
        file_info = await message.bot.get_file(file_id)
        file_path = file_info.file_path
        file_bytes = await message.bot.download_file(file_path)

        with tempfile.NamedTemporaryFile(delete=False, suffix=file_extension) as temp_file:
            temp_file.write(file_bytes.read())
            temp_file_path = temp_file.name

        # Обрабатываем в зависимости от типа
        if file_type == 'image':
            responses = await ai_service.analyze_image_as_document(user_id, temp_file_path)
        elif file_type == 'pdf':
            text = ai_service.extract_text_from_pdf(temp_file_path)
            if not text:
                await loading_msg.delete()
                await message.answer(
                    markdown_to_html(ERROR_PDF_EXTRACTION),
                    parse_mode="HTML",
                    reply_markup=persistent_keyboard
                )
                os.unlink(temp_file_path)
                return
            responses = await ai_service.analyze_document_text(user_id, text)
        elif file_type == 'docx':
            text = ai_service.extract_text_from_docx(temp_file_path)
            if not text:
                await loading_msg.delete()
                await message.answer(
                    markdown_to_html(ERROR_DOCX_EXTRACTION),
                    parse_mode="HTML",
                    reply_markup=persistent_keyboard
                )
                os.unlink(temp_file_path)
                return
            responses = await ai_service.analyze_document_text(user_id, text)

        # Удаляем сообщение о загрузке
        try:
            await loading_msg.delete()
        except:
            pass

        # Отправляем результат
        for response in responses:
            parts = split_text(response)
            for part in parts:
                await message.answer(markdown_to_html(part), parse_mode="HTML", reply_markup=persistent_keyboard)

        # Списываем кредиты
        try:
            await deduct_credits(user_id, "document_analysis")
        except Exception as e:
            logger.error(f"Ошибка при списании кредитов за документ: {e}")

        # Удаляем временный файл
        os.unlink(temp_file_path)

    except Exception as e:
        logger.error(f"Ошибка при обработке документа: {e}")
        try:
            await loading_msg.delete()
        except:
            pass
        await message.answer(
            markdown_to_html(ERROR_FILE_PROCESSING),
            parse_mode="HTML",
            reply_markup=persistent_keyboard
        )