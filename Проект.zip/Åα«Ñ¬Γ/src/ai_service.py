import openai
from config import Config
from .utils import add_disclaimer, escape_markdown
import logging
import aiofiles
from PIL import Image
import io
from typing import List
import PyPDF2
from docx import Document
import pytesseract
import base64
import httpx
from .database import SyncSessionLocal as SessionLocal
from .models import Conversation
from datetime import datetime

import os

logger = logging.getLogger('cosmetology_bot')

class AIService:
    def __init__(self):
        # Инициализация OpenRouter клиента
        if Config.OPENROUTER_API_KEY:
            logger.info("OPENROUTER_API_KEY загружен")
            logger.info(f"OpenAI version: {openai.__version__}")

            # Проверка на прокси в переменных окружения
            proxies = None
            http_proxy = os.getenv('HTTP_PROXY') or os.getenv('http_proxy')
            https_proxy = os.getenv('HTTPS_PROXY') or os.getenv('https_proxy')
            if http_proxy or https_proxy:
                proxies = {
                    'http://': http_proxy,
                    'https://': https_proxy
                }
                logger.info(f"Using proxies: {proxies}")
                http_client = httpx.Client(proxies=proxies)
                self.client = openai.OpenAI(api_key=Config.OPENROUTER_API_KEY, base_url="https://openrouter.ai/api/v1", http_client=http_client)
            else:
                self.client = openai.OpenAI(api_key=Config.OPENROUTER_API_KEY, base_url="https://openrouter.ai/api/v1")
            logger.info("OpenAI client initialized successfully")
        else:
            logger.error("OPENROUTER_API_KEY отсутствует")
            self.client = None

        # Расширенный системный промпт для AI дерматолога-косметолога в режиме чата
        self.system_prompt = """
Роль и личность:
Ты — AI-ассистент, который общается с врачами как с коллегами, работающий исключительно как интеллектуальный помощник для дипломированных врачей. Твоя цель — предоставлять врачу структурированные данные, дифференциальные диагнозы, обзоры научной литературы и шаблоны решений, чтобы ускорить и улучшить его работу. Ты сдержан, профессиональен, предельно точен и всегда подчеркиваешь, что окончательное решение принимает лечащий врач.. В твоих ответах избегай рекомендаций обращаться к врачу, поскольку пользователь уже взаимодействует с медицинскими специалистами. Вместо этого, при необходимости, рекомендуй дополнительные исследования, консультации смежных специалистов или уточняющие вопросы для более точной диагностики. Всегда предоставляй обоснованные, профессиональные советы на основе медицинских знаний, подчеркивая важность комплексного подхода к здоровью. Если информация недостаточна, проси уточнения симптомов, анамнеза или результатов анализов. 

Область знаний и источники:
Твои знания основаны на актуальных (не старше 3-5 лет, где это критично) международных клинических рекомендациях, руководствах (например, AAD, EADV, российские клинические рекомендации Минздрава), систематических обзорах Cochrane, данных FDA/EMA и авторитетных дерматологических учебниках (Fitzpatrick, Bolognia). Ты всегда стремишься к доказательному подходу (evidence-based medicine).

Ключевые функции и инструкции к ним:

Диагноз по описанию клинической картины:

Запроси уточняющие данные: возраст, пол, длительность, локализация, субъективные ощущения (зуд, боль), динамика развития, провоцирующие факторы.

Сформируй дифференциальный диагноз (ДД) в виде таблицы или списка, расположив вероятные варианты от наиболее к наименее вероятному, с кратким обоснованием для каждого.

Для каждого пункта ДД предложи ключевые диагностические шаги, которые должен предпринять врач для подтверждения/исключения (осмотр под лампой Вуда, дерматоскопия, какие именно анализы, биопсия).

Фраза-ограничитель: «Учитывая описание, наиболее вероятны [список]. Однако для верификации диагноза необходимы: [список действий]. Окончательный диагноз устанавливается врачом на очном приеме».

Расшифровка анализов:

При получении данных анализов (биохимия, гормоны, аллергопанели, иммунограмма, гистология) предоставь референсные значения и интерпретацию отклонений в контексте дерматологических заболеваний.

Укажи, какие состояния могут быть связаны с выявленными отклонениями.

Предложи, к каким специалистам может быть целесообразна консультация (эндокринолог, ревматолог и т.д.) или какие дополнительные дерматологические тесты стоит рассмотреть.

Фраза-ограничитель: «Интерпретация результатов должна проводиться в комплексе с клинической картиной. Изолированные отклонения могут не иметь клинической значимости. Рекомендую обсудить эти результаты с лечащим врачом».

Подбор лечения:

Предлагай схемы лечения только после условного «установления диагноза» врачом.

Предоставляй варианты терапии, структурированные по линии: первая линия (препараты выбора), вторая линия (альтернатива), третья линия (при резистентности).

Включай как лекарственные (топические, системные), так и аппаратные (лазеры, пилинги), инвазивные (инъекции) методы, диету и уход.

Обязательно указывай: механизм действия, стандартные схемы приема/нанесения, важнейшие побочные эффекты, противопоказания и предостережения, необходимость мониторинга (анализы крови при приеме ретиноидов, изотретиноина).

Фраза-ограничитель: «Данная схема является примерной и должна быть скорректирована врачом с учетом индивидуальных особенностей пациента, сопутствующих заболеваний и лекарственных взаимодействий. Назначение рецептурных препаратов производится только врачом».

Диагноз по фотографии:

Критически важное предупреждение: «Анализ изображения носит вспомогательный характер и не может заменить очный осмотр, пальпацию и дерматоскопию. Точность ограничена качеством снимка».

Опиши визуальные признаки: морфология элементов (папула, пустула, бляшка), цвет, границы, локализация.

Предложи наиболее вероятные дерматологические состояния, которые могут проявляться подобным образом.

Настоятельно порекомендуй метод верификации (дерматоскопия у врача, консультация онколога при подозрении на новообразование).

Фраза-ограничитель: «Особую настороженность вызывают признаки [перечисли, если есть: асимметрия, неровные края, изъязвление]. Требуется срочная очная консультация дерматолога для исключения онкопатологии».

Написание медицинских текстов (статьи, посты, доклады):
Уточни целевую аудиторию (врачи, пациенты, студенты), тон (научный, популяризированный) и объем.

Структурируй текст логично: введение, актуальность, основная часть, заключение/выводы.

Пиши для пациентов простым, понятным языком без излишней драматизации. Для врачей — используй профессиональную терминологию.

Всегда основывай утверждения на данных. В конце текста можешь предлагать формат ссылок на источники.

В постах для соцсетей предлагай привлекательные заголовки и тезисную структуру.

Общие правила и этика:

Конфиденциальность: Напоминай о важности неразглашения персональных данных и использования обезличенной информации.

Не навреди (Primum non nocere): При любых сомнениях, нехватке данных или признаках тяжелого/угрожающего состояния (некроз, синдром Стивенса-Джонсона и др.) настоятельно рекомендуй немедленную очную консультацию врача или вызов скорой помощи.

Пределы компетенции: Четко обозначай, что ты не занимаесь вопросами, требующими немедленного хирургического вмешательства, или лечением тяжелых системных заболеваний без участия профильного специалиста.

Образовательная функция: По просьбе врача объясняй патогенез заболеваний современным языком, сравнивай препараты, приводишь данные об эффективности из исследований.

Язык и стиль: Будь вежливым, сострадательным, но лаконичным и деловым. Избегай разговорных и двусмысленных формулировок. Ключевые и важные моменты в ответе выделяй жирным шрифтом.

Структура ответов (примерный шаблон):

Резюме запроса: Кратко повтори, что тебе описано/предоставлено.

Анализ/Интерпретация: Примени свои функции, как указано выше.

Рекомендации к действию для врача: Конкретные шаги (назначить анализ, провести процедуру, направить к специалисту).

Предостережения и ограничения: Повтор ключевых предупреждений.

Поддержка принятия решения: «Эта информация поможет вам в принятии клинического решения. Необходимый следующий шаг — ...»

Инициирующее сообщение от бота:
«Здравствуйте! Я  AI дерматолог-косметолог, ваш ИИ-помощник в области дерматологии и косметологии. Я здесь, чтобы помочь вам проанализировать данные, предложить дифференциальные диагнозы и обзоры литературы.. Чем я могу помочь вам сегодня? Опишите случай, загрузите фото или задайте вопрос.
"""

    def split_text(self, text: str, max_length: int = 3500) -> List[str]:
        """Разбивает текст на части по max_length символов, стараясь не разрывать слова."""
        parts = []
        while len(text) > max_length:
            split_pos = max_length
            for i in range(max_length, 0, -1):
                if text[i-1] in [' ', '\n']:
                    split_pos = i
                    break
            parts.append(text[:split_pos])
            text = text[split_pos:]
        if text:
            parts.append(text)
        return parts

    def save_conversation(self, user_id: int, message_type: str, user_message: str, bot_response: str):
        """Сохраняет сообщение и ответ в историю диалога."""
        session = SessionLocal()
        try:
            conversation = Conversation(
                user_id=user_id,
                message_type=message_type,
                user_message=user_message,
                bot_response=bot_response
            )
            session.add(conversation)
            session.commit()
            logger.info(f"Сохранена беседа для пользователя {user_id}: {message_type}")
        except Exception as e:
            logger.error(f"Ошибка при сохранении беседы: {e}")
            session.rollback()
        finally:
            session.close()

    def get_conversation_history(self, user_id: int, limit: int = 10) -> List[dict]:
        """Получает последние сообщения из истории диалога пользователя."""
        session = SessionLocal()
        try:
            conversations = session.query(Conversation).filter(
                Conversation.user_id == user_id
            ).order_by(Conversation.timestamp.desc()).limit(limit).all()

            # Возвращаем в обратном порядке (от старых к новым)
            history = []
            for conv in reversed(conversations):
                history.append({
                    'role': 'user',
                    'content': conv.user_message
                })
                history.append({
                    'role': 'assistant',
                    'content': conv.bot_response
                })
            return history
        except Exception as e:
            logger.error(f"Ошибка при получении истории беседы: {e}")
            return []
        finally:
            session.close()

    async def analyze_text_problem(self, user_id: int, problem_text: str) -> List[str]:
        """Анализ проблемы на основе текста с учетом истории диалога."""
        try:
            if not self.client:
                raise ValueError("OpenRouter клиент не инициализирован")

            # Получаем историю диалога
            history = self.get_conversation_history(user_id, limit=5)  # Последние 5 пар сообщений

            messages = [{"role": "system", "content": self.system_prompt}]

            # Добавляем историю
            messages.extend(history)

            # Добавляем текущее сообщение
            user_prompt = f"Проанализируйте описание проблемы с кожей пациента: {problem_text}. Если информация недостаточна, запросите дополнительные детали о симптомах, истории заболевания, аллергиях и результатах лабораторных исследований. Структура ответа: 1. Клиническая картина. 2. Возможные диагнозы. 3. Рекомендации по диагностике. 4. Лечение и уход."
            messages.append({"role": "user", "content": user_prompt})

            response = self.client.chat.completions.create(
                model="deepseek/deepseek-chat",
                messages=messages
            )
            result = response.choices[0].message.content
            logger.info(f"Анализ текста: {problem_text[:50]}... Длина ответа: {len(result)} символов")

            # Сохраняем в историю
            self.save_conversation(user_id, 'text', problem_text, result)

            parts = self.split_text(result)
            logger.info(f"Ответ разбит на {len(parts)} частей")
            return parts
        except Exception as e:
            logger.error(f"Ошибка при анализе текста: {e}")
            error_msg = "Извините, произошла ошибка при обработке вашего запроса. Попробуйте позже."
            return [add_disclaimer(error_msg)]

    async def analyze_document_text(self, user_id: int, document_text: str) -> List[str]:
        """Анализ текста документа с учетом истории диалога."""
        try:
            if not self.client:
                raise ValueError("OpenRouter клиент не инициализирован")

            # Получаем историю диалога
            history = self.get_conversation_history(user_id, limit=5)

            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(history)

            user_prompt = f"Проанализируйте предоставленный медицинский документ: {document_text}. Выделите ключевые медицинские данные, диагнозы, рекомендации и советы по дерматологии и косметологии. Структура ответа: 1. Ключевые insights. 2. Рекомендации."
            messages.append({"role": "user", "content": user_prompt})

            response = self.client.chat.completions.create(
                model="deepseek/deepseek-chat",
                messages=messages
            )
            result = response.choices[0].message.content
            logger.info(f"Анализ документа: {document_text[:50]}... Длина ответа: {len(result)} символов")

            # Сохраняем в историю
            self.save_conversation(user_id, 'document', f"Анализ документа: {document_text[:100]}...", result)

            parts = self.split_text(result)
            logger.info(f"Ответ разбит на {len(parts)} частей")
            return parts
        except Exception as e:
            logger.error(f"Ошибка при анализе документа: {e}")
            error_msg = "Извините, произошла ошибка при обработке вашего запроса. Попробуйте позже."
            return [add_disclaimer(error_msg)]

    async def analyze_image(self, user_id: int, image_bytes: bytes, description: str = "") -> List[str]:
        """Анализ изображения кожи с учетом истории диалога."""
        try:
            if not self.client:
                raise ValueError("OpenRouter клиент не инициализирован")

            # Получаем историю диалога
            history = self.get_conversation_history(user_id, limit=5)

            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(history)

            # Кодируем изображение в base64
            image_base64 = base64.b64encode(image_bytes).decode('utf-8')
            # Определяем MIME type изображения
            image = Image.open(io.BytesIO(image_bytes))
            mime_type = f"image/{image.format.lower()}" if image.format else "image/jpeg"
            user_prompt = f"Проанализируйте изображение кожи пациента. Описание: {description}. Структура ответа: 1. Описание видимых признаков. 2. Возможные диагнозы. 3. Рекомендации по диагностике и лечению. 4. Советы по уходу за кожей."

            messages.append({
                "role": "user",
                "content": [
                    {"type": "text", "text": user_prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime_type};base64,{image_base64}"}
                    }
                ]
            })

            response = self.client.chat.completions.create(
                model="openai/gpt-4o-mini",
                messages=messages
            )
            result = response.choices[0].message.content
            logger.info(f"Анализ изображения: {description[:50]}... Длина ответа: {len(result)} символов")

            # Сохраняем в историю
            self.save_conversation(user_id, 'photo', f"Анализ фото: {description}", result)

            parts = self.split_text(result)
            logger.info(f"Ответ разбит на {len(parts)} частей")
            return parts
        except Exception as e:
            logger.error(f"Ошибка при анализе изображения: {e}")
            error_msg = "Извините, произошла ошибка при обработке изображения. Попробуйте позже."
            return [add_disclaimer(error_msg)]

    async def generate_content_post(self, user_id: int, topic: str) -> dict:
        """Генерация контента для поста с учетом истории диалога."""
        try:
            if not self.client:
                raise ValueError("OpenRouter клиент не инициализирован")

            # Получаем историю диалога
            history = self.get_conversation_history(user_id, limit=5)

            messages = [{"role": "system", "content": self.system_prompt}]
            messages.extend(history)

            # Генерируем текст поста
            user_prompt = f"Создайте образовательный пост по теме {topic} в области дерматологии и косметологии. Включите научные факты, советы по уходу за кожей, рекомендации по аппаратам Профмедгрупп и препаратам IQ-Complex Shine. Ответ на русском языке."
            messages.append({"role": "user", "content": user_prompt})

            response = self.client.chat.completions.create(
                model="deepseek/deepseek-chat",
                messages=messages
            )
            result = response.choices[0].message.content
            logger.info(f"Генерация поста: {topic}. Длина ответа: {len(result)} символов")

            # Сохраняем в историю
            self.save_conversation(user_id, 'post', topic, result)

            parts = self.split_text(result)
            logger.info(f"Ответ разбит на {len(parts)} частей")
            return {'text': parts}
        except Exception as e:
            logger.error(f"Ошибка при генерации поста: {e}")
            error_msg = "Извините, произошла ошибка при генерации контента. Попробуйте позже."
            return {'text': [add_disclaimer(error_msg)]}

    def extract_text_from_pdf(self, file_path: str) -> str:
        """Извлекает текст из PDF файла."""
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text()
            logger.info(f"Извлечен текст из PDF: {file_path}, длина: {len(text)} символов")
            return text
        except Exception as e:
            logger.error(f"Ошибка при извлечении текста из PDF {file_path}: {e}")
            return ""

    def extract_text_from_docx(self, file_path: str) -> str:
        """Извлекает текст из DOCX файла."""
        try:
            doc = Document(file_path)
            text = ""
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"
            logger.info(f"Извлечен текст из DOCX: {file_path}, длина: {len(text)} символов")
            return text
        except Exception as e:
            logger.error(f"Ошибка при извлечении текста из DOCX {file_path}: {e}")
            return ""

    def extract_text_from_image(self, file_path: str) -> str:
        """Извлекает текст из изображения с помощью OCR."""
        try:
            image = Image.open(file_path)
            text = pytesseract.image_to_string(image, lang='rus+eng')  # Поддержка русского и английского
            logger.info(f"Извлечен текст из изображения: {file_path}, длина: {len(text)} символов")
            return text
        except Exception as e:
            logger.error(f"Ошибка при извлечении текста из изображения {file_path}: {e}")
            return ""

    async def analyze_image_as_document(self, user_id: int, file_path: str) -> List[str]:
        """Анализирует изображение как документ, извлекая текст с помощью OCR и анализируя через Gemini."""
        try:
            text = self.extract_text_from_image(file_path)
            if not text:
                error_msg = "Не удалось извлечь текст из изображения."
                return [add_disclaimer(error_msg)]
            return await self.analyze_document_text(user_id, text)
        except Exception as e:
            logger.error(f"Ошибка при анализе изображения как документа {file_path}: {e}")
            error_msg = "Извините, произошла ошибка при обработке изображения. Попробуйте позже."
            return [add_disclaimer(error_msg)]