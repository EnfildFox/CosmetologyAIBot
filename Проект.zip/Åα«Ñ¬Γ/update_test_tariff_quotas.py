#!/usr/bin/env python3
"""
Скрипт для обновления квот тестового тарифа с 20 на 10 генераций для всех типов.
Обновляет тариф 'test' для всех пользователей, имеющих этот тариф.
"""

import sys
import os

# Добавляем корневую директорию проекта в путь
sys.path.insert(0, os.path.dirname(__file__))

from config.config import Config
from src.database import SyncSessionLocal as SessionLocal
from src.models import Tariff

def update_test_tariff_quotas():
    """
    Обновляет total_requests тестового тарифа на 10.
    """
    session = SessionLocal()
    try:
        # Находим тестовый тариф
        test_tariff = session.query(Tariff).filter(Tariff.name == 'test').first()

        if not test_tariff:
            print("Тестовый тариф 'test' не найден.")
            return

        # Сохраняем старые total_requests для вывода
        old_total = test_tariff.total_requests

        # Обновляем total_requests на 10
        test_tariff.total_requests = 10

        # Сохраняем изменения
        session.commit()

        # Выводим подтверждение
        print("Успешно обновлен total_requests тестового тарифа.")
        print(f"Старый total_requests: {old_total}")
        print(f"Новый total_requests: 10")

    except Exception as e:
        session.rollback()
        print(f"Ошибка при обновлении total_requests: {e}")
    finally:
        session.close()

if __name__ == "__main__":
    update_test_tariff_quotas()