from flask import Flask, request, jsonify, render_template_string
import requests
import hashlib
import hmac
import json
from urllib.parse import unquote
from config.config import Config

app = Flask(__name__)

# Функция для проверки Telegram initData
def verify_telegram_data(init_data):
    if not init_data:
        return False

    try:
        data = {}
        for pair in init_data.split('&'):
            key, value = pair.split('=', 1)
            data[key] = unquote(value)

        hash_value = data.pop('hash', None)
        if not hash_value:
            return False

        data_check_string = '\n'.join(f'{k}={v}' for k, v in sorted(data.items()))
        secret_key = hmac.new(b'WebAppData', Config.TELEGRAM_BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated_hash = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

        return calculated_hash == hash_value
    except:
        return False

# Главная страница Mini App
@app.route('/')
def index():
    init_data = request.args.get('initData')
    if not verify_telegram_data(init_data):
        return "Unauthorized", 401

    # HTML для выбора тарифа
    html = """
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Выбор тарифа 💳</title>
        <script src="https://telegram.org/js/telegram-web-app.js"></script>
        <style>
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #fff;
                margin: 0;
                padding: 20px;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            }
            .container {
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                border-radius: 20px;
                padding: 30px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                max-width: 400px;
                width: 100%;
            }
            h1 {
                text-align: center;
                margin-bottom: 30px;
                font-size: 2em;
                text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
            }
            .tariff {
                background: rgba(255, 255, 255, 0.2);
                border-radius: 15px;
                padding: 20px;
                margin: 10px 0;
                transition: all 0.3s ease;
                cursor: pointer;
                border: 2px solid transparent;
            }
            .tariff:hover {
                background: rgba(255, 255, 255, 0.3);
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            }
            .tariff.selected {
                border-color: #ffd700;
                background: rgba(255, 215, 0, 0.2);
            }
            .tariff input[type="radio"] {
                display: none;
            }
            .tariff label {
                display: block;
                cursor: pointer;
                font-size: 1.1em;
                line-height: 1.4;
            }
            .tariff .emoji {
                font-size: 1.5em;
                margin-right: 10px;
            }
            .tariff .price {
                font-weight: bold;
                color: #ffd700;
                float: right;
            }
            button {
                background: linear-gradient(45deg, #ff6b6b, #ffa500);
                color: white;
                border: none;
                padding: 15px 30px;
                font-size: 1.2em;
                border-radius: 25px;
                cursor: pointer;
                transition: all 0.3s ease;
                width: 100%;
                margin-top: 20px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            }
            button:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
            }
            .features {
                font-size: 0.9em;
                opacity: 0.8;
                margin-top: 5px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🎉 Выберите тариф 🎉</h1>
            <form id="tariffForm">
                <div class="tariff" onclick="selectTariff('basic')">
                    <input type="radio" name="plan" value="basic" id="basic" checked>
                    <label for="basic">
                        <span class="emoji">🌟</span> Basic
                        <span class="price">400 ₽/мес</span>
                        <div class="features">💬 100 текстов/день, 📸 3 фото, 📄 1 документ</div>
                    </label>
                </div>
                <div class="tariff" onclick="selectTariff('pro')">
                    <input type="radio" name="plan" value="pro" id="pro">
                    <label for="pro">
                        <span class="emoji">🚀</span> Pro
                        <span class="price">800 ₽/мес</span>
                        <div class="features">💬 Безлим тексты, 📸 10 фото, 📄 5 док, 📝 5 постов</div>
                    </label>
                </div>
                <div class="tariff" onclick="selectTariff('vip')">
                    <input type="radio" name="plan" value="vip" id="vip">
                    <label for="vip">
                        <span class="emoji">💎</span> VIP
                        <span class="price">1500 ₽/мес</span>
                        <div class="features">🌟 Всё без ограничений!</div>
                    </label>
                </div>
                <button type="submit">💳 Оплатить</button>
            </form>
        </div>
        <script>
            function selectTariff(plan) {
                document.querySelectorAll('.tariff').forEach(t => t.classList.remove('selected'));
                document.getElementById(plan).parentElement.classList.add('selected');
                document.getElementById(plan).checked = true;
            }
            document.getElementById('tariffForm').addEventListener('submit', function(e) {
                e.preventDefault();
                const plan = document.querySelector('input[name="plan"]:checked').value;
                fetch('/create_payment', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({plan: plan, initData: window.Telegram.WebApp.initData})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.confirmation_url) {
                        window.location.href = data.confirmation_url;
                    }
                });
            });
        </script>
    </body>
    </html>
    """
    return render_template_string(html)

# Создание платежа через ЮKassa
@app.route('/create_payment', methods=['POST'])
def create_payment():
    data = request.get_json()
    init_data = data.get('initData')
    if not verify_telegram_data(init_data):
        return jsonify({"error": "Unauthorized"}), 401

    plan = data.get('plan')
    amount = {'basic': 400, 'pro': 800, 'vip': 1500}.get(plan, 400)

    # Создание платежа в ЮKassa
    payment_data = {
        "amount": {
            "value": str(amount),
            "currency": "RUB"
        },
        "confirmation": {
            "type": "redirect",
            "return_url": request.host_url + "payment_success"
        },
        "capture": True,
        "description": f"Тариф {plan}"
    }

    headers = {
        'Authorization': f'Basic {Config.YOOKASSA_SHOP_ID}:{Config.YOOKASSA_SECRET_KEY}',
        'Content-Type': 'application/json'
    }

    response = requests.post('https://api.yookassa.ru/v3/payments', json=payment_data, headers=headers)
    if response.status_code == 200:
        payment = response.json()
        return jsonify({"confirmation_url": payment['confirmation']['confirmation_url']})
    else:
        return jsonify({"error": "Payment creation failed"}), 500

# Обработка успешного платежа
@app.route('/payment_success')
def payment_success():
    # В реальности нужно проверить статус платежа через ЮKassa API
    # Для простоты, активируем тариф
    return "Тариф активирован!"

if __name__ == '__main__':
    app.run(debug=True)