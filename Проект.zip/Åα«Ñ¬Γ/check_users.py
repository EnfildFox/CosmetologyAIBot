from src.database import SyncSessionLocal
from src.models import User

session = SyncSessionLocal()
try:
    total_users = session.query(User).count()
    unblocked = session.query(User).filter(User.blocked == False).count()
    premium = session.query(User).filter(User.tariff_id.isnot(None), User.blocked == False).count()
    free = session.query(User).filter(User.tariff_id.is_(None), User.blocked == False).count()

    print(f"Total users: {total_users}")
    print(f"Unblocked: {unblocked}")
    print(f"Premium: {premium}")
    print(f"Free: {free}")

    # List some users
    users = session.query(User).filter(User.blocked == False).limit(5).all()
    for u in users:
        print(f"User {u.telegram_id}: blocked {u.blocked}, tariff {u.tariff_id}")
finally:
    session.close()