#!/usr/bin/env python3
"""
Test script for admin panel functionality.
Tests admin access checks, log viewing, settings, payment monitoring, and mass messaging.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.database import SyncSessionLocal
from src.models import User, Setting, Transaction, Tariff
from src.utils import is_admin_check
from config.config import Config
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_admin_access():
    """Test admin access checks."""
    print("=== Testing Admin Access ===")

    # Test with admin ID from config
    admin_id = Config.ADMIN_IDS[0] if Config.ADMIN_IDS else None
    if admin_id:
        is_admin = is_admin_check(admin_id)
        print(f"Admin ID {admin_id} access: {is_admin}")
        assert is_admin, f"Admin ID {admin_id} should have access"
    else:
        print("No admin IDs configured")

    # Test with non-admin ID
    non_admin_id = 999999999
    is_admin = is_admin_check(non_admin_id)
    print(f"Non-admin ID {non_admin_id} access: {is_admin}")
    assert not is_admin, f"Non-admin ID {non_admin_id} should not have access"

    print("✓ Admin access tests passed\n")

def test_settings():
    """Test settings functionality."""
    print("=== Testing Settings ===")

    session = SyncSessionLocal()
    try:
        # Check if settings exist
        settings = session.query(Setting).all()
        print(f"Found {len(settings)} settings in database")

        for setting in settings:
            print(f"  - {setting.key}: {setting.value} ({setting.description})")

        assert len(settings) > 0, "Settings should exist in database"

        # Test updating a setting
        if settings:
            setting = settings[0]
            old_value = setting.value
            setting.value = "test_value"
            session.commit()
            print(f"Updated setting {setting.key} from {old_value} to {setting.value}")

            # Restore original value
            setting.value = old_value
            session.commit()
            print(f"Restored setting {setting.key} to {old_value}")

        print("Settings tests passed")

    except Exception as e:
        print(f"Settings test failed: {e}")
        raise
    finally:
        session.close()

    print()

def test_payment_monitoring():
    """Test payment monitoring functionality."""
    print("=== Testing Payment Monitoring ===")

    session = SyncSessionLocal()
    try:
        # Get transaction statistics
        total_transactions = session.query(Transaction).count()
        payment_transactions = session.query(Transaction).filter(Transaction.amount > 0).all()
        total_revenue = sum(t.amount for t in payment_transactions)

        print(f"Total transactions: {total_transactions}")
        print(f"Payment transactions: {len(payment_transactions)}")
        print(f"Total revenue: {total_revenue:.2f} ₽")

        # Test transaction types
        package_payments = session.query(Transaction).filter(Transaction.type == "package_purchase").count()
        tariff_payments = session.query(Transaction).filter(Transaction.type == "tariff").count()

        print(f"Package purchases: {package_payments}")
        print(f"Tariff subscriptions: {tariff_payments}")

        print("Payment monitoring tests passed")

    except Exception as e:
        print(f"Payment monitoring test failed: {e}")
        raise
    finally:
        session.close()

    print()

def test_log_viewing():
    """Test log viewing functionality."""
    print("=== Testing Log Viewing ===")

    log_file = "bot.log"
    if os.path.exists(log_file):
        try:
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            print(f"Log file exists with {len(lines)} lines")

            # Test reading last 10 lines
            recent_lines = lines[-10:] if len(lines) > 10 else lines
            print("Last 10 log lines:")
            for i, line in enumerate(recent_lines, 1):
                print(f"  {i}: {line.strip()[:100]}...")

            print("Log viewing tests passed")

        except Exception as e:
            print(f"Log viewing test failed: {e}")
            raise
    else:
        print("Log file does not exist")
        raise FileNotFoundError("bot.log not found")

    print()

def test_user_management():
    """Test user management functionality."""
    print("=== Testing User Management ===")

    session = SyncSessionLocal()
    try:
        # Get user statistics
        total_users = session.query(User).count()
        admin_users = session.query(User).filter(User.is_admin == True).count()
        blocked_users = session.query(User).filter(User.blocked == True).count()

        print(f"Total users: {total_users}")
        print(f"Admin users: {admin_users}")
        print(f"Blocked users: {blocked_users}")

        # Test user creation and management
        # Create a test user with unique ID
        import time
        unique_id = int(time.time() * 1000000)  # Use timestamp for unique ID

        test_user = User(
            telegram_id=unique_id,
            credits=100.0,
            is_admin=False,
            blocked=False
        )
        session.add(test_user)
        session.commit()

        print(f"✓ Created test user with ID {test_user.id}")

        # Test updating user
        test_user.credits = 200.0
        session.commit()
        print(f"✓ Updated test user credits to {test_user.credits}")

        # Clean up - delete test user
        session.delete(test_user)
        session.commit()
        print("Cleaned up test user")

    except Exception as e:
        print(f"User management test failed: {e}")
        raise
    finally:
        session.close()

    print()

def test_mass_messaging():
    """Test mass messaging functionality."""
    print("=== Testing Mass Messaging ===")

    # Since we can't actually send messages without Telegram API,
    # we'll test the logic for user filtering

    session = SyncSessionLocal()
    try:
        # Test user filtering for broadcasts
        all_users = session.query(User).filter(User.blocked == False).count()
        premium_users = session.query(User).filter(User.tariff_id.isnot(None), User.blocked == False).count()
        free_users = session.query(User).filter(User.tariff_id.is_(None), User.blocked == False).count()

        print(f"All users (not blocked): {all_users}")
        print(f"Premium users: {premium_users}")
        print(f"Free users: {free_users}")

        print("Mass messaging logic tests passed")

    except Exception as e:
        print(f"Mass messaging test failed: {e}")
        raise
    finally:
        session.close()

    print()

def main():
    """Run all admin panel tests."""
    print("Starting Admin Panel Tests...\n")

    issues = []

    try:
        test_admin_access()
    except Exception as e:
        issues.append(f"Admin access test failed: {e}")

    try:
        test_settings()
    except Exception as e:
        issues.append(f"Settings test failed: {e}")

    try:
        test_payment_monitoring()
    except Exception as e:
        issues.append(f"Payment monitoring test failed: {e}")

    try:
        test_log_viewing()
    except Exception as e:
        issues.append(f"Log viewing test failed: {e}")

    try:
        test_user_management()
    except Exception as e:
        issues.append(f"User management test failed: {e}")

    try:
        test_mass_messaging()
    except Exception as e:
        issues.append(f"Mass messaging test failed: {e}")

    print("=== Test Results ===")
    if issues:
        print("ISSUES FOUND:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print("ALL TESTS PASSED!")

    # Additional issues from code review
    print("\n=== Code Review Issues ===")
    code_issues = [
        "Manual input for settings is incomplete (FSM not implemented)",
        "No admin command (/admin) - access only through profile",
        "No export functionality for logs or transactions",
        "Mass messaging doesn't handle rate limits properly",
        "Settings addition functionality is placeholder only"
    ]

    for issue in code_issues:
        print(f"  - {issue}")

    return len(issues) == 0

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)